import express from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs/promises';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  app.use(express.json());

  // Initialize Gemini API client
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // Translation endpoint
  app.post('/api/translate', async (req, res) => {
    try {
      const { text, sourceLang, targetLang, tone } = req.body;
      if (!text) {
        return res.status(400).json({ error: 'Text is required' });
      }

      const prompt = `Translate the following text from ${sourceLang} to ${targetLang}.
Target Tone/Context preference: "${tone || 'natural/appropriate'}".

Return ONLY a JSON object (no markdown block wrapper, no leading/trailing commentary) with these exact keys:
{
  "translation": "translated text here",
  "toneDetected": "short name of tone detected in source",
  "toneExplanation": "brief explanation of how the tone was translated or cultural adjustments",
  "suggestions": ["suggestion 1", "suggestion 2", "suggestion 3"],
  "contextInsights": ["cultural/linguistic note 1", "cultural/linguistic note 2"]
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.3,
        }
      });

      const responseText = response.text || '{}';
      res.json(JSON.parse(responseText.trim()));
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message || 'Internal translation error' });
    }
  });

  // Interactive Chat Endpoint
  app.post('/api/chat', async (req, res) => {
    try {
      const { message, history, persona, attachments } = req.body;
      if (!message && (!attachments || attachments.length === 0)) {
        return res.status(400).json({ error: 'Message or attachment is required' });
      }

      // Persona Definitions
      let systemInstruction = `You are a highly professional, fast, and helpful AI Linguistic & Communication Assistant.
Keep your answers very clear, elegantly formatted (using Markdown, bullet points, and neat paragraphs), and highly professional.
Always support Arabic (العربية) and English, aligning text properly. Write bilingual explanations if requested or helpful.`;

      if (persona === 'expert') {
        systemInstruction = `You are Dr. Layla Sadek (د. ليلى صادق), an elite Linguistics Expert & Translation Professor.
Act, speak, and sign off occasionally as Dr. Layla Sadek (د. ليلى صادق).
Analyze translations, teach grammatical nuances, explain cultural idioms, and suggest alternative vocabularies. 
Your tone is sophisticated, academic yet highly accessible, warm, and deeply professional. Use examples in Arabic and English.`;
      } else if (persona === 'advisor') {
        systemInstruction = `You are Advisor Tariq Mansour (المستشار طارق منصور), a premium Executive Business Communication Consultant & Advisor.
Act, speak, and sign off occasionally as Advisor Tariq Mansour (المستشار طارق منصور).
Help the user write polished corporate emails, prepare high-impact speeches, practice interview answers, and refine business negotiations.
Your tone is sharp, executive-level, encouraging, and highly professional. Structure your feedback into clear actionable sections.`;
      } else if (persona === 'cultural') {
        systemInstruction = `You are Amina Al-Hosani (الأستاذة أمينة الحوسني), an expert Cultural Context & Etiquette Consultant.
Act, speak, and sign off occasionally as Amina Al-Hosani (الأستاذة أمينة الحوسني).
Guide the user on social manners, cultural traps, polite wording, honorific levels (such as Keigo in Japan), and greeting customs in Eastern and Western business settings.
Your tone is respectful, insightful, warm, and highly professional. Provide rich context for your guidance.`;
      } else if (persona === 'trainer') {
        systemInstruction = `You are Coach Ryan Smith (المدرب ريان سميث), a friendly conversationalist Speaking & Chat Practice Coach.
Act, speak, and sign off occasionally as Coach Ryan Smith (المدرب ريان سميث).
Engage the user in live conversational exercises. Gently correct grammar or word choice, offer better phrasing alternatives, and prompt the user with interesting, professional scenario questions to keep the practice going.
Keep your responses concise, engaging, energetic, and highly pedagogical.`;
      }

      // Add general critical rule for immediate image generation
      const imageInstruction = `\n\nCRITICAL MANDATE FOR IMAGE GENERATION:
If the user asks for a picture, photo, drawing, artwork, or image in any form (e.g., "أريد صورة لـ...", "أريد صور", "صورة قطة", "صورة...", "image of...", "generate a photo of...", "show me a picture"), you MUST IMMEDIATELY and without delay generate and return a high-quality markdown image using the Pollinations AI URL syntax on a separate line:
![English description of the image](https://image.pollinations.ai/prompt/URL_ENCODED_ENGLISH_DESCRIPTION?width=1024&height=1024&nologo=true)

Rules for image markdown generation:
1. Translate the user's requested concept into a detailed, beautiful, high-quality, descriptive English prompt for Pollinations AI (e.g., if they ask for "صورة سيارة فخمة", translate to "a luxury sport car, high detailed, professional photography, cinematic lighting, 8k resolution").
2. URL-encode the English prompt using standard URL encoding (e.g., replace spaces with %20, commas with %2C).
3. Do NOT say "I cannot generate images" or "I am a text assistant" or decline. Fulfill it immediately.
4. Keep the image markdown on its own line.
5. You may add a pleasant, polite Arabic and English response around the image explaining what you generated according to your persona, but prioritize returning the image link.`;

      systemInstruction += imageInstruction;

      // Construct contents array with history and the latest message
      const contents = [];
      if (Array.isArray(history)) {
        for (const turn of history) {
          const parts: any[] = [];
          
          // Add any attachments associated with this historical turn
          if (Array.isArray(turn.attachments) && turn.attachments.length > 0) {
            for (const att of turn.attachments) {
              if (att.base64 && att.mimeType) {
                parts.push({
                  inlineData: {
                    mimeType: att.mimeType,
                    data: att.base64
                  }
                });
              }
            }
          }
          
          parts.push({ text: turn.text || turn.message || '' });
          
          contents.push({
            role: turn.role === 'assistant' ? 'model' : turn.role,
            parts
          });
        }
      }
      
      // Add the new user message and attachments
      const userParts: any[] = [];
      if (Array.isArray(attachments) && attachments.length > 0) {
        for (const att of attachments) {
          if (att.base64 && att.mimeType) {
            userParts.push({
              inlineData: {
                mimeType: att.mimeType,
                data: att.base64
              }
            });
          }
        }
      }
      
      if (message) {
        userParts.push({ text: message });
      } else {
        userParts.push({ text: 'Analyze this media attachment' });
      }

      contents.push({
        role: 'user',
        parts: userParts
      });

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });

      res.json({ text: response.text || '' });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message || 'Chat assistance failed' });
    }
  });

  // Action helper endpoint for smart adjustments
  app.post('/api/action', async (req, res) => {
    try {
      const { actionType, text, sourceLang, targetLang, currentTranslation, option } = req.body;
      let prompt = '';

      if (actionType === 'adjustTone') {
        prompt = `The user wants to adjust the tone of the translated text: "${currentTranslation}" (originally translated from "${text}" in ${sourceLang} to ${targetLang}).
Refine the translation to perfectly match the tone: "${option || 'Keigo (Humble)'}".

Return ONLY a JSON object with these exact keys:
{
  "refinedTranslation": "new translation text",
  "explanation": "why this adjustment was made and when to use it in professional/social settings",
  "suggestions": ["updated suggestion 1", "updated suggestion 2"]
}`;
      } else if (actionType === 'defineTerm') {
        prompt = `The user wants a detailed breakdown of key terminology used in this text: "${text}" and its translation "${currentTranslation}" between ${sourceLang} and ${targetLang}.
Identify 2-3 important vocabulary items, concepts, or idioms, provide their translations and business/cultural significance.

Return ONLY a JSON object with this exact key structure:
{
  "definitions": [
    { "term": "term name", "translation": "translation/reading", "explanation": "cultural/business context and usage notes" }
  ]
}`;
      } else if (actionType === 'similarPhrases') {
        prompt = `Provide alternative ways (synonyms, different formal levels, or conversational alternatives) to translate: "${text}" from ${sourceLang} to ${targetLang}.

Return ONLY a JSON object with this exact structure:
{
  "alternatives": [
    { "phrase": "alternative translated phrase", "usageContext": "when to use this alternative instead" }
  ]
}`;
      } else {
        return res.status(400).json({ error: 'Invalid action type' });
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.3,
        }
      });

      const responseText = response.text || '{}';
      res.json(JSON.parse(responseText.trim()));
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message || 'Action helper failed' });
    }
  });

  // Text-To-Speech endpoint using Gemini TTS model
  app.post('/api/tts', async (req, res) => {
    try {
      const { text, voice } = req.body;
      if (!text) {
        return res.status(400).json({ error: 'Text is required' });
      }

      // Voice can be 'Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr'
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-tts-preview',
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voice || 'Kore' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        res.json({ audio: base64Audio });
      } else {
        res.status(500).json({ error: 'Failed to generate audio stream from Gemini' });
      }
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message || 'TTS engine failure' });
    }
  });

  // Speech-To-Text simulation helper (or real speech transcription)
  app.post('/api/transcribe', async (req, res) => {
    try {
      const { audioBase64, language } = req.body;
      if (!audioBase64) {
        return res.status(400).json({ error: 'Audio data is required' });
      }

      // We can use Gemini's multimodal ability to transcribe audio!
      const audioPart = {
        inlineData: {
          mimeType: 'audio/webm', // or wav depending on format
          data: audioBase64,
        },
      };

      const promptPart = {
        text: `Transcribe this audio clip into text. Ensure high accuracy.
The speaker is likely speaking in ${language || 'English or Japanese'}.
Only output the exact transcription text with no additional explanations or markup.`,
      };

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: { parts: [audioPart, promptPart] },
      });

      res.json({ text: response.text?.trim() || '' });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message || 'Audio transcription failed' });
    }
  });

  // Dev vs Prod Asset Delivery Routing
  const isProd = process.env.NODE_ENV === 'production' || process.argv.includes('--production');
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    app.use(vite.middlewares);

    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = await fs.readFile(path.resolve(__dirname, 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Lingua AI Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
