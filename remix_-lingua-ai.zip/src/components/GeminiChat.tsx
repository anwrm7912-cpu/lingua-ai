import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Languages, 
  Plus, 
  Menu, 
  X, 
  ChevronRight, 
  BookOpen, 
  Briefcase, 
  Globe, 
  MessagesSquare, 
  ChevronDown, 
  CreditCard, 
  Trash2, 
  Sparkles, 
  User, 
  Loader2, 
  VolumeX, 
  Volume2, 
  Copy, 
  Send, 
  Mic, 
  Info, 
  Award, 
  ShieldCheck, 
  CheckCircle2, 
  Lock,
  Paperclip,
  Video
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ChatAttachment {
  type: 'image' | 'video';
  url: string;
  mimeType: string;
  base64: string;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  persona: 'expert' | 'advisor' | 'cultural' | 'trainer';
  attachments?: ChatAttachment[];
}

interface GeminiChatProps {
  activeTab: 'translate' | 'chat';
  setActiveTab: (tab: 'translate' | 'chat') => void;
  chatPersona: 'expert' | 'advisor' | 'cultural' | 'trainer';
  setChatPersona: (persona: 'expert' | 'advisor' | 'cultural' | 'trainer') => void;
  chatMessages: ChatMessage[];
  setChatMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  chatInput: string;
  setChatInput: (input: string) => void;
  isChatLoading: boolean;
  currentlySpeakingMessageId: string | null;
  speakChatMessage: (msg: ChatMessage) => void;
  stopSpeakingChatMessage: () => void;
  clearChatHistory: () => void;
  handleSendChatMessage: (e?: React.FormEvent, messageOverride?: string, attachmentsOverride?: ChatAttachment[]) => Promise<void>;
  playbackSpeed: number;
  setPlaybackSpeed: (speed: number) => void;
  subStatus: 'trial' | 'premium' | 'expired';
  setSubStatus: (status: 'trial' | 'premium' | 'expired') => void;
  trialDaysRemaining: number;
  setTrialDaysRemaining: React.Dispatch<React.SetStateAction<number>>;
  isPaymentModalOpen: boolean;
  setIsPaymentModalOpen: (open: boolean) => void;
  isRecording: boolean;
  setIsRecording: (recording: boolean) => void;
  errorMessage: string | null;
  setErrorMessage: (msg: string | null) => void;
  chatToast: string | null;
  showChatToast: (msg: string) => void;
  renderFormattedText: (text: string) => React.ReactNode;
  closePaymentModal: () => void;
  handleProcessPayment: (e: React.FormEvent) => void;
  selectedPayment: 'card' | 'mada' | 'apple' | 'paypal';
  setSelectedPayment: (gateway: 'card' | 'mada' | 'apple' | 'paypal') => void;
  cardHolder: string;
  setCardHolder: (name: string) => void;
  cardNumber: string;
  setCardNumber: (num: string) => void;
  cardExpiry: string;
  setCardExpiry: (exp: string) => void;
  cardCvv: string;
  setCardCvv: (cvv: string) => void;
  isProcessingPayment: boolean;
  paymentSuccess: boolean;
}

interface PersonaDetail {
  id: 'expert' | 'advisor' | 'cultural' | 'trainer';
  nameAr: string;
  nameEn: string;
  titleAr: string;
  titleEn: string;
  avatar: string;
  bioAr: string;
  bioEn: string;
  color: string;
}

const PERSONA_DETAILS: Record<'expert' | 'advisor' | 'cultural' | 'trainer', PersonaDetail> = {
  expert: {
    id: 'expert',
    nameAr: "د. ليلى صادق",
    nameEn: "Dr. Layla Sadek",
    titleAr: "خبير لغوي وأستاذ الترجمة الفورية",
    titleEn: "Linguistics Expert & Interpretation Professor",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200&h=200",
    bioAr: "متخصصة في فقه اللغة المقارن وتدريس تراكيب اللغات الأجنبية وبناء المترادفات اللغوية الفصيحة بدقة متناهية.",
    bioEn: "Specializes in comparative philology, high-fidelity grammatical structures, and deep semantic nuance explanation.",
    color: "emerald"
  },
  advisor: {
    id: 'advisor',
    nameAr: "المستشار طارق منصور",
    nameEn: "Tariq Mansour",
    titleAr: "مستشار الصياغة والتواصل المهني التنفيذي",
    titleEn: "Executive Professional Drafting & Business Coach",
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=200&h=200",
    bioAr: "خبير ومستشار في صياغة الخطابات الرسمية الحساسة، العروض التنفيذية، وإدارة مفاوضات العمل الكبرى بلباقة.",
    bioEn: "Expert in drafting critical executive emails, diplomatic business correspondence, and workplace communication structures.",
    color: "blue"
  },
  cultural: {
    id: 'cultural',
    nameAr: "الأستاذة أمينة الحوسني",
    nameEn: "Amina Al-Hosani",
    titleAr: "مستشار البروتوكول والإتيكيت العابر للثقافات",
    titleEn: "Cross-Cultural Protocol & Etiquette Expert",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200&h=200",
    bioAr: "مستشارة بروتوكول متخصصة في توجيه الكوادر وبناء الجسور الثقافية، وصياغة عبارات التحية والاحترام الملائمة لكل بلد.",
    bioEn: "Specializes in international business etiquette, high-respect greetings, and polite verbal diplomacy across cultures.",
    color: "amber"
  },
  trainer: {
    id: 'trainer',
    nameAr: "المدرب ريان سميث",
    nameEn: "Coach Ryan Smith",
    titleAr: "مدرب محادثة وطلاقة التحدث التفاعلي",
    titleEn: "Conversational Fluency & Interactive Speaking Coach",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200&h=200",
    bioAr: "مدرب محادثة ودود يساعدك على كسر حاجز الخوف والتحدث بطلاقة وثقة، مع تزويدك ببدائل حية ونطق سليم وصحيح.",
    bioEn: "Passionate practice coach focusing on building verbal fluidity, daily spoken slang, and natural confidence triggers.",
    color: "indigo"
  }
};

const PERSONA_SUGGESTIONS = {
  expert: [
    { text: "ما الفرق بين 'Do' و 'Make' بالتفصيل؟", label: "الفرق بين Do & Make" },
    { text: "ترجم عبارة: 'بشكل لائق' مع بدائلها اللغوية المهنية واليومية", label: "بدائل لغوية لـ 'بشكل لائق'" },
    { text: "اشرح لي قاعدة استخدام زمن المضارع التام بالتفصيل", label: "قاعدة المضارع التام" }
  ],
  advisor: [
    { text: "اكتب مسودة بريد رسمي للاعتذار عن حضور اجتماع بسبب طارئ باللغتين العربية والإنجليزية", label: "بريد اعتذار رسمي" },
    { text: "كيف يمكنني تحسين عبارة 'أريد وظيفة لديكم' لتصبح صياغة مهنية جذابة؟", label: "تحسين صياغة توظيف" },
    { text: "طلب زيادة راتب بأسلوب مهني ومقنع للمدير الإقليمي", label: "طلب زيادة الراتب" }
  ],
  cultural: [
    { text: "ما قواعد بروتوكول تبادل بطاقات العمل للمدراء في اليابان؟", label: "بطاقات العمل باليابان" },
    { text: "كيف أحيي شريك عمل في ألمانيا بأسلوب مهني محترم؟", label: "التحية المهنية بألمانيا" },
    { text: "ما هي الأخطاء الثقافية التي يجب تجنبها عند التعامل مع شريك خليجي؟", label: "تجنب الأخطاء الثقافية" }
  ],
  trainer: [
    { text: "دعنا نبدأ محاكاة مقابلة عمل باللغة الإنجليزية لوظيفة مستشار لغوي", label: "بدء محاكاة مقابلة" },
    { text: "صحح جملتي: 'I have went to shop yesterday' وشرح الخطأ ببساطة", label: "تصحيح خطأ لغوي" },
    { text: "ابدأ معي محادثة تعارف وتواصل مهنية واطرح علي أسئلة تفاعلية", label: "بدء محادثة تعارف" }
  ]
};

export const GeminiChat: React.FC<GeminiChatProps> = ({
  activeTab,
  setActiveTab,
  chatPersona,
  setChatPersona,
  chatMessages,
  setChatMessages,
  chatInput,
  setChatInput,
  isChatLoading,
  currentlySpeakingMessageId,
  speakChatMessage,
  stopSpeakingChatMessage,
  clearChatHistory,
  handleSendChatMessage,
  playbackSpeed,
  setPlaybackSpeed,
  subStatus,
  setSubStatus,
  trialDaysRemaining,
  setTrialDaysRemaining,
  isPaymentModalOpen,
  setIsPaymentModalOpen,
  isRecording,
  setIsRecording,
  errorMessage,
  setErrorMessage,
  chatToast,
  showChatToast,
  renderFormattedText,
  closePaymentModal,
  handleProcessPayment,
  selectedPayment,
  setSelectedPayment,
  cardHolder,
  setCardHolder,
  cardNumber,
  setCardNumber,
  cardExpiry,
  setCardExpiry,
  cardCvv,
  setCardCvv,
  isProcessingPayment,
  paymentSuccess,
}) => {
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const isAssistantSpeaking = chatMessages.some(msg => msg.role === 'assistant' && msg.id === currentlySpeakingMessageId);

  // Media upload and attachment state
  const [selectedAttachments, setSelectedAttachments] = useState<ChatAttachment[]>([]);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        const base64 = result.split(',')[1];
        resolve(base64);
      };
      reader.onerror = error => reject(error);
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    setErrorMessage(null);

    const newAttachments: ChatAttachment[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      // Limit file size to 15MB
      if (file.size > 15 * 1024 * 1024) {
        setErrorMessage("حجم الملف يتجاوز الحد الأقصى (15 ميجابايت) • File size exceeds maximum limit (15MB)");
        continue;
      }

      const isImage = file.type.startsWith('image/');
      const isVideo = file.type.startsWith('video/');

      if (!isImage && !isVideo) {
        setErrorMessage("تنسيق الملف غير مدعوم (اختر صورة أو فيديو فقط) • Unsupported file format (choose image or video only)");
        continue;
      }

      try {
        const base64 = await fileToBase64(file);
        const url = URL.createObjectURL(file);
        newAttachments.push({
          type: isImage ? 'image' : 'video',
          url,
          mimeType: file.type,
          base64
        });
      } catch (err) {
        console.error("Error reading file:", err);
        setErrorMessage("فشل في قراءة الملف • Failed to read file");
      }
    }

    setSelectedAttachments(prev => [...prev, ...newAttachments]);
    setIsUploading(false);
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeAttachment = (index: number) => {
    setSelectedAttachments(prev => {
      const updated = [...prev];
      URL.revokeObjectURL(updated[index].url);
      updated.splice(index, 1);
      return updated;
    });
  };

  // Auto scroll to bottom when messages load or change
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, isChatLoading]);

  const selectPersonaAndResetWelcome = (persona: 'expert' | 'advisor' | 'cultural' | 'trainer') => {
    setChatPersona(persona);
    const welcomeMsgText = 
      persona === 'expert'
        ? "مرحباً بك! بصفتي خبيراً لغوياً، يسعدني مساعدتك في صياغة الجمل وتوضيح النحو والترجمة الدقيقة. تفضل بطرح سؤالك.\n\nWelcome! As your linguistics advisor, I am here to help you refine structure, understand grammar, and build elegant translations. Ask away!"
        : persona === 'advisor'
        ? "أهلاً بك! أنا مستشارك المهني لتلميع المراسلات الرسمية والخطابات وتجهيز العروض المهنية. ما هو موضوع تواصلك اليوم؟\n\nWelcome! I am your professional communication advisor. Let's craft outstanding executive emails, business proposals, or interview scripts."
        : persona === 'cultural'
        ? "مرحباً! بصفتي مستشاراً ثقافياً واجتماعياً، سأرشدك لقواعد الإتيكيت والتحايا المهذبة وأسرار اللباقة المهنية عبر الثقافات.\n\nHello! I am your cultural context and etiquette advisor. Let's master formal business custom protocols, social nuances, and polite formulations."
        : "رائع! دعنا نتدرب سوياً على المحادثة الحرة والمصطلحات المهنية. اكتب لي جملاً أو عبارات وسأصححها لك وأعطيك نصائح لتلميعها.\n\nGreat! I'm your interactive speaking partner. Share any statement with me, and I will gently analyze, correct, and upgrade your vocabulary.";
    
    setChatMessages([
      {
        id: 'welcome',
        role: 'assistant',
        text: welcomeMsgText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        persona: persona
      }
    ]);
    setIsMobileSidebarOpen(false);
  };

  return (
    <div id="gemini-chat-container" className="h-screen w-screen bg-[#080808] text-white font-sans antialiased flex overflow-hidden selection:bg-indigo-500/30 selection:text-indigo-200">
      
      {/* Mobile top bar navigation */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-14 bg-[#09090b] border-b border-[#1f1f23] flex items-center justify-between px-4 z-40 select-none">
        <button 
          onClick={() => setIsMobileSidebarOpen(true)}
          className="p-2 -ml-2 text-zinc-400 hover:text-white rounded-lg bg-zinc-900/40 hover:bg-zinc-900"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <Bot className="w-4 h-4 text-[#818cf8]" />
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-300">
            {chatPersona === 'expert' ? 'Linguistics Expert' : chatPersona === 'advisor' ? 'Business Advisor' : chatPersona === 'cultural' ? 'Cultural Coach' : 'Practice Partner'}
          </span>
        </div>
        <button
          onClick={() => {
            selectPersonaAndResetWelcome(chatPersona);
            showChatToast("New conversation started • تم بدء محادثة جديدة");
          }}
          className="p-2 -mr-2 text-zinc-400 hover:text-white rounded-lg bg-zinc-900/40 hover:bg-zinc-900"
          title="New Chat"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Backdrop for mobile drawer */}
      <AnimatePresence>
        {isMobileSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsMobileSidebarOpen(false)}
            className="md:hidden fixed inset-0 bg-black/80 backdrop-blur-sm z-40"
          />
        )}
      </AnimatePresence>

      {/* Left Sidebar Layout */}
      <div className={`
        fixed inset-y-0 left-0 w-72 bg-[#09090b] border-r border-[#1f1f23] flex flex-col justify-between p-4 z-50 transform transition-transform duration-300 select-none
        md:relative md:translate-x-0 h-screen shrink-0 flex-shrink-0
        ${isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        
        <div className="flex flex-col gap-5 overflow-y-auto max-h-[80vh] pr-1">
          {/* Brand Header */}
          <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
            <div className="flex items-center gap-2.5 px-1">
              <div className="bg-[#818cf8]/10 p-2 rounded-xl border border-[#818cf8]/25 shadow-[0_0_15px_rgba(129,140,248,0.1)]">
                <Bot className="w-5 h-5 text-[#818cf8]" />
              </div>
              <div className="text-left">
                <h2 className="font-serif italic text-base font-bold text-white flex items-center gap-0.5 tracking-tight">
                  GEMINI<span className="text-[#818cf8] font-sans text-xs not-italic font-extrabold">·</span>CHAT
                </h2>
                <p className="text-[9px] font-mono uppercase tracking-widest text-zinc-500">Neural Chat Companion</p>
              </div>
            </div>

            {/* Mobile close button */}
            <button 
              onClick={() => setIsMobileSidebarOpen(false)}
              className="md:hidden p-1.5 text-zinc-500 hover:text-white rounded-lg bg-zinc-900 border border-zinc-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* New Chat Button */}
          <button
            onClick={() => {
              selectPersonaAndResetWelcome(chatPersona);
              showChatToast("New conversation started • تم بدء محادثة جديدة");
            }}
            className="w-full flex items-center justify-center gap-2 border border-zinc-800 hover:border-zinc-700 bg-zinc-900/50 hover:bg-zinc-900 text-zinc-200 text-xs font-semibold py-3 px-4 rounded-xl transition-all cursor-pointer shadow-sm active:scale-95"
          >
            <Plus className="w-4 h-4 text-[#818cf8]" />
            <span>New Chat • محادثة جديدة</span>
          </button>

          {/* Workspace Switcher */}
          <div>
            <span className="text-[10px] uppercase font-mono text-zinc-600 px-2 tracking-widest block mb-2">Workspace Layout</span>
            <button
              onClick={() => {
                setActiveTab('translate');
                setIsMobileSidebarOpen(false);
              }}
              className="w-full flex items-center justify-between px-3 py-2.5 text-xs text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-900/60 transition-colors border border-transparent hover:border-zinc-850/50 cursor-pointer text-left"
            >
              <div className="flex items-center gap-2.5">
                <Languages className="w-4 h-4 text-zinc-500" />
                <span>Translator • محرك الترجمة</span>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-zinc-600" />
            </button>
          </div>

          {/* AI Personas / Models list */}
          <div className="flex flex-col gap-2">
            <span className="text-[10px] uppercase font-mono text-zinc-600 px-2 tracking-widest block mb-1">AI Personas • الشخصيات الذكية</span>
            
            {/* Expert Button */}
            <button
              onClick={() => {
                selectPersonaAndResetWelcome('expert');
                showChatToast("Linguistics Expert active • تم تنشيط د. ليلى صادق");
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex gap-3 items-center text-xs ${
                chatPersona === 'expert'
                  ? 'bg-emerald-950/25 border-emerald-500/40 text-emerald-300 shadow-[0_4px_15px_rgba(16,185,129,0.05)]'
                  : 'bg-zinc-900/20 border-zinc-900 hover:border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <img 
                src={PERSONA_DETAILS.expert.avatar} 
                alt="Dr. Layla" 
                className="w-8 h-8 rounded-full object-cover shrink-0 border border-emerald-500/20"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-zinc-200">{PERSONA_DETAILS.expert.nameAr}</span>
                  {chatPersona === 'expert' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
                </div>
                <p className="text-[10px] text-zinc-500 truncate mt-0.5">{PERSONA_DETAILS.expert.titleEn}</p>
              </div>
            </button>

            {/* Advisor Button */}
            <button
              onClick={() => {
                selectPersonaAndResetWelcome('advisor');
                showChatToast("Business Advisor active • تم تنشيط طارق منصور");
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex gap-3 items-center text-xs ${
                chatPersona === 'advisor'
                  ? 'bg-blue-950/25 border-blue-500/40 text-blue-300 shadow-[0_4px_15px_rgba(59,130,246,0.05)]'
                  : 'bg-zinc-900/20 border-zinc-900 hover:border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <img 
                src={PERSONA_DETAILS.advisor.avatar} 
                alt="Tariq Mansour" 
                className="w-8 h-8 rounded-full object-cover shrink-0 border border-blue-500/20"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-zinc-200">{PERSONA_DETAILS.advisor.nameAr}</span>
                  {chatPersona === 'advisor' && <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />}
                </div>
                <p className="text-[10px] text-zinc-500 truncate mt-0.5">{PERSONA_DETAILS.advisor.titleEn}</p>
              </div>
            </button>

            {/* Cultural Button */}
            <button
              onClick={() => {
                selectPersonaAndResetWelcome('cultural');
                showChatToast("Cultural Advisor active • تم تنشيط أمينة الحوسني");
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex gap-3 items-center text-xs ${
                chatPersona === 'cultural'
                  ? 'bg-amber-950/25 border-amber-500/40 text-amber-300 shadow-[0_4px_15px_rgba(245,158,11,0.05)]'
                  : 'bg-zinc-900/20 border-zinc-900 hover:border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <img 
                src={PERSONA_DETAILS.cultural.avatar} 
                alt="Amina" 
                className="w-8 h-8 rounded-full object-cover shrink-0 border border-amber-500/20"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-zinc-200">{PERSONA_DETAILS.cultural.nameAr}</span>
                  {chatPersona === 'cultural' && <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />}
                </div>
                <p className="text-[10px] text-zinc-500 truncate mt-0.5">{PERSONA_DETAILS.cultural.titleEn}</p>
              </div>
            </button>

            {/* Practice Button */}
            <button
              onClick={() => {
                selectPersonaAndResetWelcome('trainer');
                showChatToast("Speaking Partner active • تم تنشيط ريان سميث");
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex gap-3 items-center text-xs ${
                chatPersona === 'trainer'
                  ? 'bg-indigo-950/25 border-[#818cf8]/40 text-indigo-300 shadow-[0_4px_15px_rgba(129,140,248,0.05)]'
                  : 'bg-zinc-900/20 border-zinc-900 hover:border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <img 
                src={PERSONA_DETAILS.trainer.avatar} 
                alt="Ryan Smith" 
                className="w-8 h-8 rounded-full object-cover shrink-0 border border-indigo-500/20"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-zinc-200">{PERSONA_DETAILS.trainer.nameAr}</span>
                  {chatPersona === 'trainer' && <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />}
                </div>
                <p className="text-[10px] text-zinc-500 truncate mt-0.5">{PERSONA_DETAILS.trainer.titleEn}</p>
              </div>
            </button>
          </div>

          {/* Speech speed and audio controls */}
          <div className="bg-zinc-950/40 border border-zinc-900 rounded-xl p-3 flex flex-col gap-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-zinc-500 uppercase tracking-wider">
              <span>Speech Settings</span>
              <span className="text-[#818cf8] font-bold">{playbackSpeed}x speed</span>
            </div>
            <div className="flex gap-1.5">
              {[0.5, 1.0, 1.5].map((speed) => (
                <button
                  key={speed}
                  onClick={() => setPlaybackSpeed(speed)}
                  className={`flex-1 py-1 text-[10px] font-mono font-bold rounded border transition-colors cursor-pointer ${
                    playbackSpeed === speed
                      ? 'bg-[#818cf8]/15 text-[#818cf8] border-[#818cf8]/25'
                      : 'bg-zinc-900/40 hover:bg-zinc-900 text-zinc-500 border-zinc-900 hover:border-zinc-800'
                  }`}
                >
                  {speed}x
                </button>
              ))}
            </div>
            {currentlySpeakingMessageId && (
              <button
                onClick={stopSpeakingChatMessage}
                className="w-full mt-1 py-1.5 bg-red-950/20 border border-red-900/20 hover:bg-red-950/40 text-red-400 rounded text-[10px] font-mono font-bold flex items-center justify-center gap-1.5 cursor-pointer animate-pulse"
              >
                <VolumeX className="w-3 h-3" />
                Stop Assistant Speech
              </button>
            )}
          </div>

        </div>

        {/* Sidebar Footer: Subscription Panel */}
        <div className="pt-3 border-t border-zinc-900 flex flex-col gap-3">
          
          <div className="bg-zinc-950/80 border border-zinc-900/60 rounded-xl p-3">
            <div className="flex items-center justify-between mb-1.5">
              <span className={`text-[9px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                subStatus === 'premium' 
                  ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/20' 
                  : subStatus === 'expired'
                  ? 'bg-rose-950/40 text-rose-400 border-rose-800/20'
                  : 'bg-indigo-950/40 text-indigo-400 border-indigo-800/20'
              }`}>
                {subStatus === 'premium' ? 'Premium • مميز' : subStatus === 'expired' ? 'Expired • منتهي' : 'Free Trial • تجريبي'}
              </span>
              {subStatus === 'trial' && (
                <span className="text-[10px] font-mono text-zinc-400 font-bold">{trialDaysRemaining}d left</span>
              )}
            </div>
            
            <p className="text-[10px] text-zinc-400 leading-snug">
              {subStatus === 'premium' 
                ? 'Unlimited Gemini 3.5 High-Speed' 
                : subStatus === 'expired'
                ? 'Access expired. Upgrade below.'
                : `${trialDaysRemaining} days left in trial period.`}
            </p>

            {subStatus !== 'premium' && (
              <button
                onClick={() => setIsPaymentModalOpen(true)}
                className="w-full mt-2 py-2 bg-[#818cf8] hover:bg-indigo-400 text-zinc-950 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
              >
                <CreditCard className="w-3.5 h-3.5" />
                Upgrade • ترقية الاشتراك
              </button>
            )}
          </div>

          {/* Sandbox controls dropdown */}
          <details className="group border border-zinc-900 rounded-lg overflow-hidden">
            <summary className="list-none flex items-center justify-between p-2 text-[9px] font-mono text-zinc-600 hover:text-zinc-400 uppercase tracking-widest cursor-pointer bg-zinc-950/20">
              <span>Sandbox Sandbox</span>
              <ChevronDown className="w-3 h-3 transition-transform group-open:rotate-180" />
            </summary>
            <div className="p-2 bg-zinc-950/60 border-t border-zinc-900 flex flex-col gap-1.5">
              {subStatus === 'trial' && (
                <button 
                  onClick={() => setTrialDaysRemaining(prev => Math.max(0, prev - 1))}
                  disabled={trialDaysRemaining === 0}
                  className="w-full text-[9px] font-mono bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 p-1 rounded text-zinc-400 hover:text-white disabled:opacity-30 cursor-pointer"
                >
                  -1 Day
                </button>
              )}
              <button 
                onClick={() => {
                  if (subStatus === 'premium') {
                    setSubStatus('trial');
                    setTrialDaysRemaining(7);
                  } else {
                    setSubStatus('premium');
                  }
                }}
                className="w-full text-[9px] font-mono bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 p-1 rounded text-zinc-400 hover:text-white cursor-pointer"
              >
                {subStatus === 'premium' ? 'Reset to Trial' : 'Set Premium'}
              </button>
            </div>
          </details>

        </div>
      </div>

      {/* Main Right Side Chat Canvas */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative bg-[#0d0d10] pt-14 md:pt-0">
        
        {/* Top Header Panel */}
        <div className="h-16 border-b border-[#1f1f23] flex items-center justify-between px-6 bg-[#0c0c0e] shrink-0 select-none">
          <div className="hidden md:flex items-center gap-3">
            <div className="relative">
              <img 
                src={PERSONA_DETAILS[chatPersona].avatar} 
                alt={PERSONA_DETAILS[chatPersona].nameEn}
                className={`w-10 h-10 rounded-full object-cover border-2 transition-all ${
                  isAssistantSpeaking 
                    ? 'border-[#818cf8] shadow-[0_0_12px_rgba(129,140,248,0.5)] scale-105' 
                    : 'border-zinc-800'
                }`}
                referrerPolicy="no-referrer"
              />
              {isAssistantSpeaking && (
                <span className="absolute bottom-0 right-0 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#818cf8] opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#818cf8]"></span>
                </span>
              )}
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                <span>{PERSONA_DETAILS[chatPersona].nameAr} • {PERSONA_DETAILS[chatPersona].nameEn}</span>
                <span className={`text-[9px] font-mono px-2 py-0.5 rounded-full border transition-all ${
                  isAssistantSpeaking 
                    ? 'bg-indigo-500/10 text-[#818cf8] border-indigo-500/20' 
                    : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/15'
                }`}>
                  {isAssistantSpeaking ? 'Speaking... • يتحدث الآن' : 'Active • متصل'}
                </span>
              </h3>
              <p className="text-[10px] text-zinc-500">
                {PERSONA_DETAILS[chatPersona].titleAr} • {PERSONA_DETAILS[chatPersona].titleEn}
              </p>
            </div>
          </div>

          {/* Clear chat logs button */}
          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={clearChatHistory}
              className="text-zinc-500 hover:text-zinc-300 text-xs flex items-center gap-1.5 bg-zinc-900/40 hover:bg-zinc-900 px-3 py-1.5 rounded-lg border border-zinc-850/60 transition-colors cursor-pointer"
              title="Clear current conversation"
            >
              <Trash2 className="w-3.5 h-3.5 text-zinc-500" />
              <span>Clear Chat • مسح المحادثة</span>
            </button>
          </div>
        </div>

        {/* Message Feed Canvas */}
        <div className="flex-1 overflow-y-auto px-4 py-6 md:p-8 flex flex-col">
          <div className="max-w-3xl mx-auto w-full flex-1 flex flex-col">
            
            {chatMessages.length <= 1 ? (
              /* Immersive Hero Welcome (ChatGPT / Gemini style) */
              <div className="flex-1 flex flex-col items-center justify-center py-8 text-center max-w-xl mx-auto my-auto font-sans select-none">
                <div className="relative mb-6">
                  <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500 to-purple-500 rounded-full blur-xl opacity-30 animate-pulse" />
                  <img 
                    src={PERSONA_DETAILS[chatPersona].avatar} 
                    alt={PERSONA_DETAILS[chatPersona].nameEn}
                    className="w-28 h-28 rounded-full object-cover border-4 border-zinc-800 shadow-2xl relative z-10"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute -bottom-2 right-1 z-20 bg-[#818cf8] text-zinc-950 p-1.5 rounded-full border-2 border-[#0d0d10] shadow-lg">
                    <Sparkles className="w-4 h-4" />
                  </div>
                </div>
                
                <h3 className="text-xl md:text-2xl font-black text-white tracking-tight leading-tight">
                  {PERSONA_DETAILS[chatPersona].nameAr} • {PERSONA_DETAILS[chatPersona].nameEn}
                </h3>
                <p className="text-[#818cf8] text-xs font-semibold mt-1 font-mono uppercase tracking-wider">
                  {PERSONA_DETAILS[chatPersona].titleAr}
                </p>
                
                <div className="bg-zinc-900/40 border border-zinc-850/60 rounded-2xl p-4 mt-4 text-xs text-zinc-300 leading-relaxed max-w-md">
                  <p className="mb-2 font-sans text-right" style={{ direction: 'rtl' }}>
                    "{PERSONA_DETAILS[chatPersona].bioAr}"
                  </p>
                  <p className="font-sans text-left border-t border-zinc-850/40 pt-2 text-zinc-400">
                    "{PERSONA_DETAILS[chatPersona].bioEn}"
                  </p>
                </div>

                <p className="text-zinc-500 text-xs mt-6">
                  ابدأ المحادثة معي مباشرة، أو اختر أحد الأسئلة المقترحة بالأسفل لتجربتي:
                </p>
                
                {/* 2x2 grid of modern suggested prompt cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full mt-6 text-left">
                  {PERSONA_SUGGESTIONS[chatPersona].map((suggestion, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSendChatMessage(undefined, suggestion.text)}
                      className="bg-zinc-900/30 hover:bg-[#818cf8]/10 border border-zinc-850 hover:border-[#818cf8]/30 p-5 rounded-2xl text-left transition-all cursor-pointer group hover:scale-[1.01] active:scale-95 flex flex-col justify-between"
                    >
                      <div>
                        <span className="text-[9px] font-mono font-bold text-[#818cf8] uppercase tracking-wider block">Prompt Idea • مقترح</span>
                        <h4 className="text-xs group-hover:text-white font-sans font-bold mt-2 leading-snug text-zinc-200">
                          {suggestion.label}
                        </h4>
                      </div>
                      <p className="text-[10px] text-zinc-500 group-hover:text-zinc-400 mt-2 font-sans truncate w-full">
                        "{suggestion.text}"
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              /* Standard chat thread layout */
              <div className="flex-1 flex flex-col gap-6 mb-24 pb-4">
                <AnimatePresence initial={false}>
                  {chatMessages.map((msg) => {
                    const isUser = msg.role === 'user';
                    const isMsgSpeaking = currentlySpeakingMessageId === msg.id;
                    const hasArabicText = /[\u0600-\u06FF]/.test(msg.text);

                    return (
                      <motion.div
                        key={msg.id}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2 }}
                        className={`flex gap-4 w-full ${isUser ? 'justify-end' : 'justify-start'}`}
                      >
                        {/* Assist icon avatar */}
                        {!isUser && (
                          <div className="relative shrink-0">
                            <img 
                              src={PERSONA_DETAILS[msg.persona || chatPersona].avatar} 
                              alt={PERSONA_DETAILS[msg.persona || chatPersona].nameEn}
                              className={`w-9 h-9 rounded-full object-cover border transition-all ${
                                isMsgSpeaking 
                                  ? 'border-[#818cf8] shadow-[0_0_8px_rgba(129,140,248,0.4)] scale-105' 
                                  : 'border-zinc-800'
                              }`}
                              referrerPolicy="no-referrer"
                            />
                            {isMsgSpeaking && (
                              <span className="absolute -bottom-0.5 -right-0.5 flex h-2.5 w-2.5">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#818cf8] opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#818cf8]"></span>
                              </span>
                            )}
                          </div>
                        )}

                        <div className={`flex flex-col gap-1.5 max-w-[85%] ${isUser ? 'items-end' : 'items-start'}`}>
                          {/* Message Header */}
                          <div className="flex items-center gap-2 px-1 text-[9px] text-zinc-500 font-mono">
                            {isUser ? (
                              <>
                                <span>{msg.timestamp}</span>
                                <span className="text-zinc-700">•</span>
                                <span className="text-indigo-400 font-bold uppercase">You</span>
                              </>
                            ) : (
                              <>
                                <span className="text-[#818cf8] font-bold">
                                  {PERSONA_DETAILS[msg.persona || chatPersona].nameAr} • {PERSONA_DETAILS[msg.persona || chatPersona].nameEn}
                                </span>
                                <span className="text-zinc-700">•</span>
                                <span>{msg.timestamp}</span>
                              </>
                            )}
                          </div>

                          {/* Message bubble itself */}
                          <div
                            className={`p-4 rounded-2xl border text-sm leading-relaxed ${
                              isUser
                                ? 'bg-[#818cf8]/10 border-[#818cf8]/20 text-zinc-100 rounded-tr-none'
                                : 'bg-[#18181b]/60 border-zinc-850 text-zinc-100 rounded-tl-none'
                            }`}
                            style={{ direction: hasArabicText ? 'rtl' : 'ltr', textAlign: hasArabicText ? 'right' : 'left' }}
                          >
                            {msg.attachments && msg.attachments.length > 0 && (
                              <div className="flex flex-wrap gap-2 mb-3">
                                {msg.attachments.map((att, attIdx) => {
                                  const displayUrl = att.url || `data:${att.mimeType};base64,${att.base64}`;
                                  return (
                                    <div key={attIdx} className="relative group max-w-xs rounded-xl overflow-hidden border border-zinc-800 bg-zinc-950/40">
                                      {att.type === 'image' ? (
                                        <img 
                                          src={displayUrl} 
                                          alt="Attached Image" 
                                          className="max-h-56 object-contain rounded-lg shadow-md"
                                          referrerPolicy="no-referrer"
                                        />
                                      ) : (
                                        <video 
                                          src={displayUrl} 
                                          controls 
                                          className="max-h-56 rounded-lg shadow-md" 
                                        />
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            )}

                            <div className="whitespace-pre-wrap select-text selection:bg-[#818cf8]/30 selection:text-white">
                              {renderFormattedText(msg.text)}
                            </div>

                            {/* Soundwave animation for Speech Synthesis */}
                            {isMsgSpeaking && (
                              <div className="flex items-center gap-1.5 mt-3 pt-2.5 border-t border-zinc-850 justify-start">
                                <span className="text-[10px] text-[#818cf8] font-mono uppercase tracking-widest font-bold">Speaking...</span>
                                <div className="flex items-end gap-0.5 h-3">
                                  {[1, 2, 3, 4, 5].map((bar) => (
                                    <span
                                      key={bar}
                                      className="w-0.5 bg-[#818cf8] rounded-full animate-bounce"
                                      style={{
                                        height: `${20 + Math.random() * 80}%`,
                                        animationDuration: `${0.2 + Math.random() * 0.3}s`
                                      }}
                                    />
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Message Footer Actions */}
                          {!isUser && (
                            <div className="flex items-center gap-1.5 px-1 mt-0.5">
                              <button
                                type="button"
                                onClick={() => speakChatMessage(msg)}
                                className={`p-1.5 rounded-lg border text-[10px] font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                                  isMsgSpeaking
                                    ? 'bg-red-500/10 border-red-500/20 text-red-400 hover:bg-red-500/15'
                                    : 'bg-zinc-900 hover:bg-zinc-850 border-zinc-800 text-zinc-400 hover:text-white'
                                }`}
                              >
                                {isMsgSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                                <span>{isMsgSpeaking ? 'Stop' : 'Listen'}</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  navigator.clipboard.writeText(msg.text);
                                  showChatToast('Text copied! • تم نسخ النص بنجاح');
                                }}
                                className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-zinc-400 hover:text-white text-[10px] font-mono flex items-center gap-1.5 transition-all cursor-pointer"
                              >
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copy</span>
                              </button>
                            </div>
                          )}
                        </div>

                        {/* User custom icon avatar */}
                        {isUser && (
                          <div className="w-8 h-8 rounded-full bg-zinc-850 border border-zinc-800 flex items-center justify-center text-zinc-300 shrink-0">
                            <User className="w-4 h-4" />
                          </div>
                        )}
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            )}

            {/* Chat loader / thinking animation */}
            {isChatLoading && (
              <div className="flex gap-4 w-full justify-start animate-pulse">
                <div className="w-8 h-8 rounded-full bg-zinc-900 border border-zinc-850 flex items-center justify-center text-zinc-500 shrink-0">
                  <Loader2 className="w-4 h-4 animate-spin text-zinc-500" />
                </div>
                <div className="flex flex-col gap-1 text-xs">
                  <span className="text-zinc-600 font-mono text-[9px]">Linguistics Bot is thinking...</span>
                  <div className="bg-zinc-900/40 border border-zinc-850/40 p-3 rounded-2xl rounded-tl-none text-zinc-500 max-w-sm">
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-zinc-600 animate-bounce delay-75" />
                      <span className="w-1.5 h-1.5 rounded-full bg-zinc-600 animate-bounce delay-150" />
                      <span className="w-1.5 h-1.5 rounded-full bg-zinc-600 animate-bounce delay-300" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div ref={chatEndRef} className="h-2" />
          </div>
        </div>

        {/* Floating Bottom Input Bar */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[#0d0d10] via-[#0d0d10] to-[#0d0d10]/0 px-4 pt-10 pb-6 border-t border-[#1f1f23]/20 z-20 shrink-0">
          <div className="max-w-3xl mx-auto w-full flex flex-col gap-2.5">
            
            {/* Attachment Previews */}
            {selectedAttachments.length > 0 && (
              <div className="flex flex-wrap gap-2.5 px-3 py-2.5 bg-zinc-950/60 border border-zinc-850/60 rounded-2xl mb-1.5 backdrop-blur-sm shadow-lg max-h-48 overflow-y-auto">
                {selectedAttachments.map((att, idx) => (
                  <div key={idx} className="relative w-20 h-20 rounded-xl overflow-hidden border border-zinc-800 group bg-zinc-900 shadow-md">
                    {att.type === 'image' ? (
                      <img 
                        src={att.url} 
                        alt="Preview" 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-900 text-zinc-400">
                        <Video className="w-5 h-5 text-indigo-400 mb-1" />
                        <span className="text-[8px] uppercase tracking-wider font-mono truncate max-w-[70px]">Video</span>
                      </div>
                    )}
                    {/* Delete button */}
                    <button
                      type="button"
                      onClick={() => removeAttachment(idx)}
                      className="absolute top-1 right-1 bg-black/80 hover:bg-rose-950 border border-zinc-800 text-zinc-300 hover:text-rose-400 p-1.5 rounded-full transition-colors cursor-pointer"
                    >
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Input field layout */}
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                handleSendChatMessage(e, undefined, selectedAttachments);
                setSelectedAttachments([]);
              }} 
              className="flex gap-3.5 items-stretch"
            >
              {/* Hidden file input */}
              <input 
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*,video/*"
                multiple
                className="hidden"
              />

              {/* Attachment Button */}
              <button
                type="button"
                onClick={() => {
                  if (subStatus === 'expired') {
                    setErrorMessage("انتهت الفترة التجريبية المجانية! يرجى الترقية إلى الباقة المميزة لمتابعة استخدام محرك الترجمة والدردشة.");
                    setIsPaymentModalOpen(true);
                    return;
                  }
                  fileInputRef.current?.click();
                }}
                disabled={isUploading || isChatLoading}
                className="p-3.5 rounded-2xl border border-zinc-800 bg-zinc-900 hover:bg-zinc-850 text-zinc-400 hover:text-white transition-all shrink-0 cursor-pointer flex items-center justify-center disabled:opacity-50"
                title="Attach Images or Videos • إرفاق صور أو فيديو"
              >
                {isUploading ? (
                  <Loader2 className="w-4 h-4 animate-spin text-[#818cf8]" />
                ) : (
                  <Paperclip className="w-4 h-4" />
                )}
              </button>

              {/* Voice input mic button */}
              <button
                type="button"
                onClick={() => {
                  if (subStatus === 'expired') {
                    setErrorMessage("انتهت الفترة التجريبية المجانية! يرجى الترقية إلى الباقة المميزة لمتابعة استخدام محرك الترجمة والدردشة.");
                    setIsPaymentModalOpen(true);
                    return;
                  }

                  setIsRecording(true);
                  setErrorMessage(null);
                  
                  setTimeout(() => {
                    setIsRecording(false);
                    
                    let transcribedSpeech = '';
                    if (chatPersona === 'expert') {
                      transcribedSpeech = "ما هو الفرق بين صيغة الفعل المضارع البسيط والمستمر؟";
                    } else if (chatPersona === 'advisor') {
                      transcribedSpeech = "أحتاج لمسودة سريعة لبريد رسمي لإلغاء الموعد.";
                    } else if (chatPersona === 'cultural') {
                      transcribedSpeech = "كيف يقدم المدراء بطاقات العمل في اليابان؟";
                    } else {
                      transcribedSpeech = "أريد التدرب على تحية العملاء باللغة الإنجليزية في الفندق.";
                    }
                    
                    setChatInput(transcribedSpeech);
                  }, 2000);
                }}
                className={`p-3.5 rounded-2xl border transition-all shrink-0 cursor-pointer flex items-center justify-center ${
                  isRecording
                    ? 'bg-rose-500/10 border-rose-500/30 text-rose-400 animate-pulse'
                    : 'bg-zinc-900 hover:bg-zinc-850 border-zinc-800 text-zinc-400 hover:text-white'
                }`}
                title="Speech-to-Text Voice Recording"
              >
                <Mic className={`w-4 h-4 ${isRecording ? 'scale-110' : ''}`} />
              </button>

              {/* Text input cell */}
              <div className="flex-1 relative flex items-center">
                <textarea
                  rows={1}
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendChatMessage(e, undefined, selectedAttachments);
                      setSelectedAttachments([]);
                    }
                  }}
                  placeholder={
                    isRecording
                      ? "Recording audio... • جاري تسجيل الصوت..."
                      : "Type message... • اكتب استفسارك هنا..."
                  }
                  disabled={isRecording || isChatLoading}
                  className="w-full bg-zinc-950/70 border border-zinc-800/80 hover:border-zinc-700/80 focus:border-[#818cf8] rounded-2xl pl-4 pr-12 py-3.5 text-sm text-zinc-100 placeholder-zinc-500 outline-none transition-all focus:shadow-[0_0_15px_rgba(129,140,248,0.1)] resize-none max-h-32 min-h-[48px] overflow-y-auto leading-relaxed"
                />
                
                {/* Send Button */}
                <button
                  type="submit"
                  disabled={(!chatInput.trim() && selectedAttachments.length === 0) || isChatLoading || isRecording}
                  className="absolute right-2.5 bottom-2 bg-[#818cf8] hover:bg-[#818cf8]/90 disabled:bg-zinc-900 text-zinc-950 disabled:text-zinc-600 p-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center shadow-[0_2px_8px_rgba(129,140,248,0.15)] disabled:shadow-none"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>

            {/* Disclaimer text */}
            <p className="text-[10px] text-zinc-600 text-center select-none font-sans leading-relaxed">
              Gemini can make mistakes. Verify important info. • قد يرتكب الذكاء الاصطناعي أخطاءً، يرجى التحقق من المعلومات المهمة.
            </p>

          </div>
        </div>

        {/* Floating custom toasts in right panel */}
        <AnimatePresence>
          {chatToast && (
            <motion.div
              initial={{ opacity: 0, y: 15, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed bottom-24 right-6 bg-zinc-950/95 border border-zinc-850 px-4 py-3 rounded-xl flex items-center gap-2.5 text-xs text-indigo-300 font-mono shadow-[0_4px_25px_rgba(0,0,0,0.6)] z-50 select-none"
            >
              <Sparkles className="w-4 h-4 text-[#818cf8]" />
              <span>{chatToast}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Floating error box */}
        {errorMessage && (
          <div className="absolute top-16 left-6 right-6 p-4 bg-red-950/30 border border-red-900/40 text-red-200 rounded-xl text-xs flex items-start gap-3 z-30">
            <Info className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">AI Assistant Alert</p>
              <p className="text-zinc-400 text-[10px] mt-1">{errorMessage}</p>
            </div>
            <button onClick={() => setErrorMessage(null)} className="ml-auto text-zinc-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>

      {/* Embedded global modal */}
      <AnimatePresence>
        {isPaymentModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="bg-[#0f0f12] border border-[#222222] rounded-3xl w-full max-w-lg p-6 sm:p-8 flex flex-col gap-5 relative shadow-[0_10px_50px_rgba(0,0,0,0.85)] max-h-[95vh] overflow-y-auto text-left"
            >
              {/* Close button */}
              <button
                onClick={closePaymentModal}
                disabled={isProcessingPayment}
                className="absolute top-4 right-4 text-zinc-400 hover:text-white p-2 rounded-full bg-zinc-900/60 hover:bg-zinc-800 transition-colors cursor-pointer"
                title="Close modal"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Modal head */}
              {!paymentSuccess ? (
                <div>
                  <div className="mx-auto sm:mx-0 bg-amber-500/10 border border-amber-500/20 text-amber-400 p-2.5 rounded-xl inline-block mb-3">
                    <Award className="w-6 h-6" />
                  </div>
                  <h2 className="font-serif italic text-2xl text-white">
                    Upgrade to Premium • ترقية الاشتراك
                  </h2>
                  <p className="text-zinc-400 text-xs mt-1">
                    Start your 1-week free trial, then continue for just <strong className="text-[#818cf8]">$25 for 2 months</strong>.
                  </p>
                </div>
              ) : null}

              {/* Processing card transaction */}
              {isProcessingPayment ? (
                <div className="py-12 flex flex-col items-center justify-center text-center gap-4">
                  <Loader2 className="w-12 h-12 text-[#818cf8] animate-spin" />
                  <div className="space-y-1">
                    <p className="text-sm font-mono text-zinc-300">
                      Processing secure payment transaction...
                    </p>
                    <p className="text-xs text-zinc-500">
                      Securing connection with bank network via PCI-DSS 3D-Secure...
                    </p>
                  </div>
                </div>
              ) : paymentSuccess ? (
                /* Success screen */
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-8 flex flex-col items-center justify-center text-center gap-5"
                >
                  <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-4 rounded-full inline-block">
                    <CheckCircle2 className="w-12 h-12" />
                  </div>
                  
                  <div>
                    <h3 className="font-serif italic text-2xl text-white">
                      Subscription Activated! • تم التفعيل بنجاح!
                    </h3>
                    <p className="text-zinc-400 text-sm mt-2 leading-relaxed max-w-sm mx-auto">
                      Your premium account is now active with unlimited translation capability for <strong className="text-emerald-400">2 months</strong>.
                    </p>
                  </div>

                  <button
                    onClick={closePaymentModal}
                    className="mt-4 w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-semibold py-3 rounded-xl transition-all duration-200 shadow-[0_4px_15px_rgba(16,185,129,0.3)] cursor-pointer"
                  >
                    Start Translating • ابدأ استخدام الترجمة المميزة
                  </button>
                </motion.div>
              ) : (
                /* Payment input fields */
                <div className="flex flex-col gap-5">
                  
                  {/* Plan overview info box */}
                  <div className="bg-zinc-950/80 rounded-2xl p-4 border border-zinc-900 flex flex-col gap-2">
                    <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                      <span className="text-xs text-zinc-400">Plan Option:</span>
                      <span className="text-xs font-mono font-bold text-amber-400 uppercase">Dual-Month Saver</span>
                    </div>
                    <div className="flex justify-between items-start pt-1">
                      <div>
                        <p className="text-sm font-serif font-bold text-white">1-Week Free Trial, then $25</p>
                        <p className="text-[11px] text-zinc-500">Includes offline pack support & full AI glossary</p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-mono font-bold text-white">$25.00</p>
                        <p className="text-[9px] text-zinc-500 uppercase font-mono tracking-widest">2 Months</p>
                      </div>
                    </div>
                  </div>

                  {/* Payment provider tabs */}
                  <div className="grid grid-cols-4 gap-2">
                    {(['card', 'mada', 'apple', 'paypal'] as const).map((gateway) => (
                      <button
                        key={gateway}
                        type="button"
                        onClick={() => setSelectedPayment(gateway)}
                        className={`py-2 px-1.5 rounded-xl border text-xs font-mono font-bold text-center transition-all cursor-pointer capitalize ${
                          selectedPayment === gateway
                            ? 'bg-indigo-600/15 border-[#818cf8] text-[#818cf8]'
                            : 'bg-zinc-900 hover:bg-zinc-850 border-zinc-800 text-zinc-400'
                        }`}
                      >
                        {gateway}
                      </button>
                    ))}
                  </div>

                  <form onSubmit={handleProcessPayment} className="flex flex-col gap-4">
                    {selectedPayment === 'card' || selectedPayment === 'mada' ? (
                      <>
                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] uppercase font-mono tracking-widest text-zinc-500">Cardholder Name</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Anwar Al-Mutairi"
                            value={cardHolder}
                            onChange={(e) => setCardHolder(e.target.value)}
                            className="bg-zinc-950 border border-zinc-850 focus:border-[#818cf8] rounded-xl px-4 py-3 text-sm text-zinc-100 placeholder-zinc-600 outline-none transition-all"
                          />
                        </div>
                        
                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] uppercase font-mono tracking-widest text-zinc-500">Card Number</label>
                          <div className="relative">
                            <input
                              type="text"
                              required
                              placeholder="4000 1234 5678 9010"
                              maxLength={19}
                              value={cardNumber}
                              onChange={(e) => {
                                const val = e.target.value.replace(/\s?/g, '').replace(/(\d{4})/g, '$1 ').trim();
                                setCardNumber(val);
                              }}
                              className="bg-zinc-950 border border-zinc-850 focus:border-[#818cf8] rounded-xl pl-10 pr-4 py-3 text-sm text-zinc-100 placeholder-zinc-600 outline-none transition-all w-full font-mono"
                            />
                            <CreditCard className="w-4 h-4 text-zinc-500 absolute left-3.5 top-4" />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] uppercase font-mono tracking-widest text-zinc-500">Expiration</label>
                            <input
                              type="text"
                              required
                              placeholder="MM/YY"
                              maxLength={5}
                              value={cardExpiry}
                              onChange={(e) => {
                                let val = e.target.value;
                                if (val.length === 2 && !val.includes('/')) {
                                  val = val + '/';
                                }
                                setCardExpiry(val);
                              }}
                              className="bg-zinc-950 border border-zinc-850 focus:border-[#818cf8] rounded-xl px-4 py-3 text-sm text-zinc-100 placeholder-zinc-600 outline-none transition-all text-center font-mono"
                            />
                          </div>
                          
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] uppercase font-mono tracking-widest text-zinc-500">CVV Code</label>
                            <div className="relative">
                              <input
                                type="password"
                                required
                                placeholder="***"
                                maxLength={4}
                                value={cardCvv}
                                onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                                className="bg-zinc-950 border border-zinc-850 focus:border-[#818cf8] rounded-xl px-4 py-3 text-sm text-zinc-100 placeholder-zinc-600 outline-none transition-all text-center font-mono w-full"
                              />
                              <Lock className="w-3.5 h-3.5 text-zinc-600 absolute right-3.5 top-4 pointer-events-none" />
                            </div>
                          </div>
                        </div>
                      </>
                    ) : selectedPayment === 'apple' ? (
                      <div className="bg-zinc-950/60 p-6 rounded-2xl border border-zinc-900 text-center flex flex-col items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white font-bold text-xl">
                          
                        </div>
                        <p className="text-xs text-zinc-400">Confirm biometric authentication (Face ID / Touch ID) on your Apple device to authorize payment.</p>
                      </div>
                    ) : (
                      <div className="bg-[#003087]/5 p-6 rounded-2xl border border-[#003087]/20 text-center flex flex-col items-center gap-3">
                        <div className="text-indigo-400 font-extrabold italic text-xl">
                          PayPal
                        </div>
                        <p className="text-xs text-zinc-400">Redirecting to external PayPal login screen to authenticate secure purchase flow.</p>
                      </div>
                    )}

                    <button
                      type="submit"
                      className="bg-[#818cf8] hover:bg-[#818cf8]/90 text-zinc-950 font-bold py-3.5 rounded-xl text-sm transition-all flex items-center justify-center gap-2 cursor-pointer mt-2 shadow-[0_4px_15px_rgba(129,140,248,0.25)] active:scale-95"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Authorize Secure Payment • إتمام الدفع الآمن</span>
                    </button>
                  </form>

                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};
