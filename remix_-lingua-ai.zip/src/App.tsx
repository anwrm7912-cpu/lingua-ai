import React, { useState, useEffect, useRef } from 'react';
import { 
  Languages, 
  Mic, 
  Volume2, 
  Copy, 
  Check, 
  Settings, 
  Sparkles, 
  History, 
  BookOpen, 
  ArrowLeftRight, 
  Loader2, 
  Trash2, 
  VolumeX, 
  Play, 
  Square, 
  Save, 
  Plus, 
  X, 
  ChevronDown, 
  ChevronRight,
  Menu,
  Globe, 
  RefreshCw,
  Info,
  Wifi,
  WifiOff,
  Download,
  HardDrive,
  CreditCard,
  Lock,
  ShieldCheck,
  Award,
  Calendar,
  Gauge,
  CheckCircle2,
  Briefcase,
  MessagesSquare,
  Send,
  User,
  Bot
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  translateOffline, 
  INITIAL_LANGUAGE_PACKS, 
  LanguagePack, 
  OfflineTranslationResult 
} from './offlineEngine';
import { GeminiChat } from './components/GeminiChat';

interface Note {
  id: string;
  sourceText: string;
  translatedText: string;
  sourceLang: string;
  targetLang: string;
  timestamp: string;
}

interface Definition {
  term: string;
  translation: string;
  explanation: string;
}

interface Alternative {
  phrase: string;
  usageContext: string;
}

interface ChatAttachment {
  type: 'image' | 'video';
  url: string;
  mimeType: string;
  base64: string;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  persona: 'expert' | 'advisor' | 'cultural' | 'trainer';
  attachments?: ChatAttachment[];
}

const parseInlineStyles = (line: string) => {
  const parts = line.split(/(\*\*.*?\*\*|`.*?`)/g);
  return parts.map((part, index) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={index} className="font-bold text-white font-sans">{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith('`') && part.endsWith('`')) {
      return <code key={index} className="px-1.5 py-0.5 rounded bg-zinc-800 text-indigo-300 font-mono text-[11px] border border-zinc-750">{part.slice(1, -1)}</code>;
    }
    return part;
  });
};

const renderFormattedText = (text: string) => {
  let inCodeBlock = false;
  let codeBlockLines: string[] = [];
  
  const parsedElements: React.ReactNode[] = [];
  const lines = text.split('\n');
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    // Check for code block start/end
    if (line.trim().startsWith('```')) {
      if (inCodeBlock) {
        // End code block
        const codeText = codeBlockLines.join('\n');
        parsedElements.push(
          <div key={`code-${i}`} className="my-2.5 rounded-lg border border-zinc-800 bg-[#0a0a0c] overflow-hidden select-text">
            <div className="flex items-center justify-between px-4 py-1.5 bg-[#141416] border-b border-zinc-800 text-[10px] font-mono text-zinc-400">
              <span>Code • برمجية</span>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(codeText);
                }}
                className="hover:text-white transition-colors cursor-pointer flex items-center gap-1"
              >
                <Copy className="w-3 h-3" />
                <span>Copy • نسخ</span>
              </button>
            </div>
            <pre className="p-4 overflow-x-auto text-left" style={{ direction: 'ltr' }}>
              <code className="text-xs font-mono text-indigo-200 whitespace-pre leading-relaxed">{codeText}</code>
            </pre>
          </div>
        );
        codeBlockLines = [];
        inCodeBlock = false;
      } else {
        inCodeBlock = true;
      }
      continue;
    }
    
    if (inCodeBlock) {
      codeBlockLines.push(line);
      continue;
    }
    
    // Check for header
    if (line.trim().startsWith('###')) {
      parsedElements.push(
        <h4 key={i} className="text-sm font-bold text-white mt-3 mb-1 flex items-center gap-1.5 font-sans">
          {parseInlineStyles(line.trim().replace(/^###\s*/, ''))}
        </h4>
      );
      continue;
    }
    if (line.trim().startsWith('##')) {
      parsedElements.push(
        <h3 key={i} className="text-base font-bold text-indigo-300 mt-4 mb-2 font-sans border-b border-zinc-850 pb-1">
          {parseInlineStyles(line.trim().replace(/^##\s*/, ''))}
        </h3>
      );
      continue;
    }
    if (line.trim().startsWith('#')) {
      parsedElements.push(
        <h2 key={i} className="text-lg font-extrabold text-white mt-4 mb-2 font-sans">
          {parseInlineStyles(line.trim().replace(/^#\s*/, ''))}
        </h2>
      );
      continue;
    }
    
    // Check for lists
    if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
      parsedElements.push(
        <li key={i} className="ml-5 list-disc text-xs text-zinc-300 leading-relaxed font-sans mt-1">
          {parseInlineStyles(line.trim().replace(/^[-*]\s+/, ''))}
        </li>
      );
      continue;
    }
    
    if (/^\d+\.\s+/.test(line.trim())) {
      parsedElements.push(
        <li key={i} className="ml-5 list-decimal text-xs text-zinc-300 leading-relaxed font-sans mt-1">
          {parseInlineStyles(line.trim().replace(/^\d+\.\s+/, ''))}
        </li>
      );
      continue;
    }
    
    // Support markdown image syntax: ![alt](url)
    if (line.includes('![') && line.includes('](')) {
      const match = line.match(/!\[(.*?)\]\((.*?)\)/);
      if (match) {
        const alt = match[1];
        let src = match[2].trim();
        if (src.includes(' ')) {
          src = src.replace(/\s+/g, '%20');
        }
        parsedElements.push(
          <div key={i} className="my-3 rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-950/40 p-2 shadow-xl max-w-lg">
            <img 
              src={src} 
              alt={alt} 
              className="w-full h-auto object-contain rounded-xl max-h-96" 
              referrerPolicy="no-referrer" 
            />
            {alt && <p className="text-[10px] text-zinc-400 mt-1.5 text-center font-mono">{alt}</p>}
          </div>
        );
        continue;
      }
    }
    
    // Standard paragraph
    if (!line.trim()) {
      parsedElements.push(<div key={i} className="h-2" />);
    } else {
      parsedElements.push(
        <p key={i} className="text-xs text-zinc-300 leading-relaxed font-sans mt-1">
          {parseInlineStyles(line)}
        </p>
      );
    }
  }
  
  return parsedElements;
};

const PERSONA_SUGGESTIONS = {
  expert: [
    { text: "ما الفرق بين 'Do' و 'Make' بالتفصيل؟", label: "الفرق بين Do & Make" },
    { text: "ترجم عبارة: 'بشكل لائق' مع بدائلها اللغوية المهنية واليومية", label: "بدائل لغوية لـ 'بشكل لائق'" },
    { text: "اشرح لي قاعدة استخدام زمن المضارع التام بالتفصيل", label: "قاعدة المضارع التام" }
  ],
  advisor: [
    { text: "اكتب مسودة بريد رسمي للاعتذار عن حضور اجتماع بسبب طارئ طارئ باللغتين العربية والإنجليزية", label: "بريد اعتذار رسمي" },
    { text: "كيف يمكنني تحسين عبارة 'أريد وظيفة لديكم' لتصبح صياغة مهنية جذابة؟", label: "تحسين صياغة توظيف" },
    { text: "طلب زيادة راتب بأسلوب مهني ومقنع للمدير الإقليمي", label: "طلب زيادة الراتب" }
  ],
  cultural: [
    { text: "ما قواعد بروتوكول تبادل بطاقات العمل للمدراء في اليابان؟", label: "بطاقات العمل باليابان" },
    { text: "كيف أحيي شريك عمل في ألمانيا بأسلوب مهني محترم؟", label: "التحية المهنية بألمانيا" },
    { text: "ما هي الأخطاء الثقافية التي يجب تجنبها عند التعامل مع شريك خليجي؟", label: "تجنب الأخطاء الثقافية" }
  ],
  trainer: [
    { text: "دعنا نبدأ محاكاة مقابلة عمل باللغة الإنجليزية لوظيفة مستشار لغوي", label: "بدء محاكاة مقابلة" },
    { text: "صحح جملتي: 'I have went to shop yesterday' وشرح الخطأ ببساطة", label: "تصحيح خطأ لغوي" },
    { text: "ابدأ معي محادثة تعارف وتواصل مهنية واطرح علي أسئلة تفاعلية", label: "بدء محادثة تعارف" }
  ]
};

export default function App() {
  // Input & Translate States
  const [sourceText, setSourceText] = useState<string>(
    '"The executive committee is expecting a detailed report on the fiscal realignment strategy by Monday morning."'
  );
  const [translatedText, setTranslatedText] = useState<string>(
    '「執行委員会は、月曜日の朝までに財政再編戦略に関する詳細な報告書を期待しています。」'
  );
  const [sourceLang, setSourceLang] = useState<string>('English (US)');
  const [targetLang, setTargetLang] = useState<string>('Japanese (JP)');
  const [selectedTone, setSelectedTone] = useState<string>('Corporate Formal');
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  
  // Smart Sidebar States
  const [toneDetected, setToneDetected] = useState<string>('Formal Business');
  const [toneExplanation, setToneExplanation] = useState<string>(
    "I've detected a formal business tone. Suitable for senior executives or clients."
  );
  const [suggestions, setSuggestions] = useState<string[]>([
    'Yes, adjust tone',
    "Define 'Realignment'",
    'Similar Phrases'
  ]);
  const [contextInsights, setContextInsights] = useState<string[]>([
    "Terminology: 'Fiscal realignment' is often translated as '財政再編' in corporate Japan.",
    "Cultural Note: In Japan, 'Monday morning' implies early start (9:00 AM) unless specified."
  ]);
  const [definitions, setDefinitions] = useState<Definition[]>([]);
  const [alternatives, setAlternatives] = useState<Alternative[]>([]);
  
  // Offline & Language Pack States
  const [isOffline, setIsOffline] = useState<boolean>(() => {
    return localStorage.getItem('lingua_ai_offline') === 'true';
  });
  const [languagePacks, setLanguagePacks] = useState<LanguagePack[]>(() => {
    const stored = localStorage.getItem('lingua_ai_language_packs');
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch (e) {
        return INITIAL_LANGUAGE_PACKS;
      }
    }
    return INITIAL_LANGUAGE_PACKS;
  });

  useEffect(() => {
    localStorage.setItem('lingua_ai_offline', String(isOffline));
  }, [isOffline]);

  useEffect(() => {
    localStorage.setItem('lingua_ai_language_packs', JSON.stringify(languagePacks));
  }, [languagePacks]);

  const isSourceArabic = sourceLang.includes('Arabic') || sourceLang.includes('AR');
  const isTargetArabic = targetLang.includes('Arabic') || targetLang.includes('AR');

  // Download language pack simulator
  const downloadLanguagePack = (packId: string) => {
    setLanguagePacks(prev => prev.map(p => {
      if (p.id === packId) {
        return { ...p, isDownloading: true, downloadProgress: 0 };
      }
      return p;
    }));

    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.floor(Math.random() * 15) + 10;
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        setLanguagePacks(prev => prev.map(p => {
          if (p.id === packId) {
            return { ...p, isDownloading: false, downloaded: true, downloadProgress: 100 };
          }
          return p;
        }));
      } else {
        setLanguagePacks(prev => prev.map(p => {
          if (p.id === packId) {
            return { ...p, downloadProgress: progress };
          }
          return p;
        }));
      }
    }, 150);
  };

  const deleteLanguagePack = (packId: string) => {
    setLanguagePacks(prev => prev.map(p => {
      if (p.id === packId) {
        return { ...p, downloaded: false, downloadProgress: 0, isDownloading: false };
      }
      return p;
    }));
  };
  
  // Interaction & UI Feedback States
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [copiedInput, setCopiedInput] = useState<boolean>(false);
  const [copiedOutput, setCopiedOutput] = useState<boolean>(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  // Saved Notes History (persisted in localStorage)
  const [savedNotes, setSavedNotes] = useState<Note[]>([]);
  const [showHistoryOnly, setShowHistoryOnly] = useState<boolean>(false);

  // Chat Feature States
  const [activeTab, setActiveTab] = useState<'translate' | 'chat'>('translate');
  const [chatPersona, setChatPersona] = useState<'expert' | 'advisor' | 'cultural' | 'trainer'>('expert');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const stored = localStorage.getItem('lingua_ai_chat_messages');
    if (stored) {
      try { return JSON.parse(stored); } catch (e) {}
    }
    return [
      {
        id: 'welcome',
        role: 'assistant',
        text: "مرحباً بك في ساحة الدردشة اللغوية التفاعلية! أنا خبير الترجمة واللغويات الخاص بك. كيف يمكنني مساعدتك اليوم في تلميع نصوصك أو فهم الفروق اللغوية الدقيقة؟\n\nWelcome to the Interactive Linguistics Chat! I am your senior language and translation expert. How can I help you refine your sentences or understand complex grammatical nuances today?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        persona: 'expert'
      }
    ];
  });
  const [chatInput, setChatInput] = useState<string>('');
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);
  const [currentlySpeakingMessageId, setCurrentlySpeakingMessageId] = useState<string | null>(null);
  const [chatToast, setChatToast] = useState<string | null>(null);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);

  const chatEndRef = useRef<HTMLDivElement>(null);

  const showChatToast = (msg: string) => {
    setChatToast(msg);
    setTimeout(() => {
      setChatToast(null);
    }, 2500);
  };

  const scrollToBottom = () => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages, isChatLoading, activeTab]);

  useEffect(() => {
    localStorage.setItem('lingua_ai_chat_messages', JSON.stringify(chatMessages));
  }, [chatMessages]);

  // Subscription & Payment States
  const [subStatus, setSubStatus] = useState<'trial' | 'premium' | 'expired'>(() => {
    const stored = localStorage.getItem('lingua_ai_sub_status');
    return (stored as 'trial' | 'premium' | 'expired') || 'trial';
  });
  const [trialDaysRemaining, setTrialDaysRemaining] = useState<number>(() => {
    const stored = localStorage.getItem('lingua_ai_trial_days');
    return stored ? parseInt(stored, 10) : 7;
  });
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState<boolean>(false);
  const [paymentSuccess, setPaymentSuccess] = useState<boolean>(false);
  const [selectedPayment, setSelectedPayment] = useState<'card' | 'mada' | 'apple' | 'paypal'>('card');
  const [cardNumber, setCardNumber] = useState<string>('');
  const [cardExpiry, setCardExpiry] = useState<string>('');
  const [cardCvv, setCardCvv] = useState<string>('');
  const [cardHolder, setCardHolder] = useState<string>('');
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem('lingua_ai_sub_status', subStatus);
  }, [subStatus]);

  useEffect(() => {
    localStorage.setItem('lingua_ai_trial_days', trialDaysRemaining.toString());
  }, [trialDaysRemaining]);

  // Time & Location States
  const [currentTime, setCurrentTime] = useState<string>('');
  const [locationStr, setLocationStr] = useState<string>('Tokyo, JP');

  // Waveform Bar Animation Heights state
  const [waveHeights, setWaveHeights] = useState<number[]>([20, 50, 80, 40, 90, 60, 30, 50, 70, 40, 85, 55, 25]);
  const waveIntervalRef = useRef<any>(null);
  const recordingIntervalRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  // Playback Speed State (0.5x, 1x, 1.5x)
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);

  // Sync playback speed to the active source node dynamically if audio is playing
  useEffect(() => {
    if (audioSourceRef.current) {
      try {
        audioSourceRef.current.playbackRate.value = playbackSpeed;
      } catch (e) {
        console.error("Failed to dynamically set playback speed on buffer source:", e);
      }
    }
  }, [playbackSpeed]);

  // Preset quick sentences
  const quickPresets = [
    {
      label: 'Formal Proposal',
      text: 'We are prepared to finalize the strategic partnership agreement subject to minor board adjustments.',
    },
    {
      label: 'Technical Review',
      text: 'The latency spike is caused by database connection pool saturation under peak traffic load.',
    },
    {
      label: 'Polite Inquiry',
      text: 'Could you please confirm your availability for a alignment call next Thursday afternoon?',
    },
    {
      label: 'Polite Decline',
      text: 'While we appreciate your generous invitation, we must respectfully decline due to resource limits.',
    }
  ];

  // Load persisted history & update clock
  useEffect(() => {
    // Clock
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      }));
    };
    updateTime();
    const clockInterval = setInterval(updateTime, 1000);

    // Notes
    const stored = localStorage.getItem('lingua_ai_notes');
    if (stored) {
      try {
        setSavedNotes(JSON.parse(stored));
      } catch (e) {
        console.error('Error parsing notes:', e);
      }
    }

    // Attempt to guess city or fallback to timezone representation
    try {
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
      if (tz.includes('Tokyo')) setLocationStr('Tokyo, JP');
      else if (tz.includes('New_York')) setLocationStr('New York, US');
      else if (tz.includes('London')) setLocationStr('London, UK');
      else if (tz.includes('Paris')) setLocationStr('Paris, FR');
      else {
        const parts = tz.split('/');
        setLocationStr(`${parts[parts.length - 1]?.replace('_', ' ') || 'Local'}, Global`);
      }
    } catch (_) {}

    return () => {
      clearInterval(clockInterval);
      if (waveIntervalRef.current) clearInterval(waveIntervalRef.current);
      if (recordingIntervalRef.current) clearInterval(recordingIntervalRef.current);
    };
  }, []);

  // Sync wave animation when speaking or recording
  useEffect(() => {
    if (isPlayingAudio || isRecording || isTranslating) {
      waveIntervalRef.current = setInterval(() => {
        setWaveHeights(prev => prev.map(() => Math.floor(Math.random() * 80) + 15));
      }, 120);
    } else {
      if (waveIntervalRef.current) {
        clearInterval(waveIntervalRef.current);
        waveIntervalRef.current = null;
      }
      setWaveHeights([20, 50, 80, 40, 90, 60, 30, 50, 70, 40, 85, 55, 25]);
    }
  }, [isPlayingAudio, isRecording, isTranslating]);

  // Translate handle
  const handleTranslate = async (overrideText?: string, customTone?: string) => {
    const textToUse = overrideText !== undefined ? overrideText : sourceText;
    if (!textToUse.trim()) return;

    if (subStatus === 'expired') {
      setIsPaymentModalOpen(true);
      setErrorMessage("انتهت الفترة التجريبية المجانية! يرجى الترقية إلى الباقة المميزة لمتابعة استخدام محرك الترجمة الذكي.");
      return;
    }

    setIsTranslating(true);
    setErrorMessage(null);
    setAudioError(null);

    // If Offline Mode is active, translate on-device
    if (isOffline) {
      const srcPack = languagePacks.find(p => p.code === sourceLang);
      const tgtPack = languagePacks.find(p => p.code === targetLang);
      
      const srcMissing = srcPack && !srcPack.downloaded;
      const tgtMissing = tgtPack && !tgtPack.downloaded;
      
      if (srcMissing || tgtMissing) {
        const missingLangs = [];
        if (srcMissing) missingLangs.push(sourceLang);
        if (tgtMissing) missingLangs.push(targetLang);
        
        setIsTranslating(false);
        setErrorMessage(`Offline translation is unavailable. You need to download the language pack for ${missingLangs.join(' and ')} first.`);
        return;
      }

      // Optimized lightning-fast on-device translation calculation
      setTimeout(() => {
        try {
          const result = translateOffline(textToUse, sourceLang, targetLang, customTone || selectedTone);
          setTranslatedText(result.translation);
          setToneDetected(result.toneDetected);
          setToneExplanation(result.toneExplanation);
          setSuggestions(result.suggestions);
          setContextInsights(result.contextInsights);
          setDefinitions(result.definitions || []);
          setAlternatives(result.alternatives || []);
        } catch (err: any) {
          setErrorMessage("Offline translation engine failed: " + err.message);
        } finally {
          setIsTranslating(false);
        }
      }, 40);
      return;
    }

    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: textToUse,
          sourceLang,
          targetLang,
          tone: customTone || selectedTone
        }),
      });

      if (!response.ok) {
        throw new Error('Server returned error status ' + response.status);
      }

      const data = await response.json();
      setTranslatedText(data.translation || '');
      setToneDetected(data.toneDetected || 'Detected Tone');
      setToneExplanation(data.toneExplanation || '');
      setSuggestions(data.suggestions || ['Define Term', 'Similar Phrases']);
      setContextInsights(data.contextInsights || []);
      
      // Clear secondary panels on new query
      setDefinitions([]);
      setAlternatives([]);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Failed to communicate with AI translation engine.');
    } finally {
      setIsTranslating(false);
    }
  };

  // Switch direction
  const swapLanguages = () => {
    const tempLang = sourceLang;
    setSourceLang(targetLang);
    setTargetLang(tempLang);

    const tempText = sourceText;
    setSourceText(translatedText);
    setTranslatedText(tempText);
  };

  // AI smart chips actions
  const handleSuggestionAction = async (chip: string) => {
    // Determine target action based on chips
    let actionType = '';
    let option = '';

    const lowerChip = chip.toLowerCase();
    if (lowerChip.includes('adjust') || lowerChip.includes('tone') || lowerChip.includes('keigo') || lowerChip.includes('friendly')) {
      actionType = 'adjustTone';
      if (lowerChip.includes('keigo')) option = 'Keigo (Humble)';
      else if (lowerChip.includes('friendly')) option = 'Friendly Casual';
      else option = 'Keigo (Humble/Polite)';
    } else if (lowerChip.includes('define') || lowerChip.includes('term') || lowerChip.includes('realignment')) {
      actionType = 'defineTerm';
    } else if (lowerChip.includes('phrases') || lowerChip.includes('similar')) {
      actionType = 'similarPhrases';
    } else {
      // Default to similar phrases
      actionType = 'similarPhrases';
    }

    setIsTranslating(true);

    if (isOffline) {
      setTimeout(() => {
        if (actionType === 'adjustTone') {
          const result = translateOffline(sourceText, sourceLang, targetLang, option);
          setTranslatedText(result.translation);
          setToneDetected(result.toneDetected);
          setToneExplanation(result.toneExplanation);
          if (result.suggestions) {
            setSuggestions(result.suggestions);
          }
        } else if (actionType === 'defineTerm') {
          const result = translateOffline(sourceText, sourceLang, targetLang, selectedTone);
          if (result.definitions && result.definitions.length > 0) {
            setDefinitions(result.definitions);
          } else {
            setDefinitions([
              { term: "Project deliverables", translation: "プロジェクトの成果物 (seikabutsu)", explanation: "Specific products or results created and delivered for a project's completion." }
            ]);
          }
        } else if (actionType === 'similarPhrases') {
          const result = translateOffline(sourceText, sourceLang, targetLang, selectedTone);
          if (result.alternatives && result.alternatives.length > 0) {
            setAlternatives(result.alternatives);
          } else {
            setAlternatives([
              { phrase: "直ちに合意を形成する必要があります。", usageContext: "A direct, formal alternative translation." },
              { phrase: "We must align on deliverables.", usageContext: "Simplified alternative formulation." }
            ]);
          }
        }
        setIsTranslating(false);
      }, 40);
      return;
    }

    try {
      const response = await fetch('/api/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          actionType,
          text: sourceText,
          sourceLang,
          targetLang,
          currentTranslation: translatedText,
          option
        }),
      });

      if (!response.ok) throw new Error('Action endpoint error');

      const data = await response.json();
      if (actionType === 'adjustTone') {
        if (data.refinedTranslation) {
          setTranslatedText(data.refinedTranslation);
        }
        if (data.explanation) {
          setToneExplanation(data.explanation);
        }
        if (data.suggestions) {
          setSuggestions(data.suggestions);
        }
      } else if (actionType === 'defineTerm') {
        if (data.definitions) {
          setDefinitions(data.definitions);
        }
      } else if (actionType === 'similarPhrases') {
        if (data.alternatives) {
          setAlternatives(data.alternatives);
        }
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage('Failed to trigger AI Smart Assistant feature.');
    } finally {
      setIsTranslating(false);
    }
  };

  // TTS Output
  const speakTranslation = async () => {
    if (!translatedText.trim()) return;
    if (isPlayingAudio) {
      stopAudio();
      return;
    }

    setIsPlayingAudio(true);
    setAudioError(null);

    try {
      const isJapanese = targetLang.includes('Japanese') || targetLang.includes('JP');
      const voice = isJapanese ? 'Kore' : isTargetArabic ? 'Charon' : 'Zephyr';

      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: translatedText, voice }),
      });

      if (!response.ok) throw new Error('Speech synthesis error');

      const data = await response.json();
      if (data.audio) {
        playPcm(data.audio);
      } else {
        throw new Error('No audio payload received');
      }
    } catch (err: any) {
      console.error(err);
      setAudioError(err.message || 'TTS playback failed.');
      // Fallback: use Web Speech API
      try {
        const synth = window.speechSynthesis;
        if (synth) {
          const utterance = new SpeechSynthesisUtterance(translatedText);
          const isJapanese = targetLang.includes('Japanese') || targetLang.includes('JP');
          utterance.lang = isJapanese ? 'ja-JP' : isTargetArabic ? 'ar-SA' : 'en-US';
          utterance.rate = playbackSpeed;
          utterance.onend = () => setIsPlayingAudio(false);
          synth.speak(utterance);
        } else {
          setIsPlayingAudio(false);
        }
      } catch (_) {
        setIsPlayingAudio(false);
      }
    }
  };

  // Playback PCM 24kHz utility
  const playPcm = (base64Pcm: string, sampleRate = 24000) => {
    try {
      const binary = atob(base64Pcm);
      const len = binary.length;
      const buffer = new ArrayBuffer(len);
      const view = new DataView(buffer);
      // Construct native ArrayBuffer
      const bytes = new Uint8Array(buffer);
      for (let i = 0; i < len; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      
      // PCM 16-bit little endian
      const pcmData = new Int16Array(buffer);
      
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioCtxClass({ sampleRate });
      audioContextRef.current = audioCtx;

      const audioBuffer = audioCtx.createBuffer(1, pcmData.length, sampleRate);
      const channelData = audioBuffer.getChannelData(0);
      for (let i = 0; i < pcmData.length; i++) {
        channelData[i] = pcmData[i] / 32768; // Normalize 16-bit to float range [-1.0, 1.0]
      }
      
      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.playbackRate.value = playbackSpeed;
      source.connect(audioCtx.destination);
      
      audioSourceRef.current = source;
      source.onended = () => {
        setIsPlayingAudio(false);
      };
      source.start(0);
    } catch (err) {
      console.error('PCM playback failed:', err);
      setIsPlayingAudio(false);
    }
  };

  const stopAudio = () => {
    try {
      if (audioSourceRef.current) {
        audioSourceRef.current.stop();
        audioSourceRef.current = null;
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
        audioContextRef.current = null;
      }
    } catch (e) {}
    try {
      window.speechSynthesis.cancel();
    } catch (_) {}
    setIsPlayingAudio(false);
  };

  // Recording Simulate
  const startRecording = () => {
    if (isRecording) {
      stopRecording();
      return;
    }
    setIsRecording(true);
    setRecordingSeconds(0);
    setErrorMessage(null);

    recordingIntervalRef.current = setInterval(() => {
      setRecordingSeconds(prev => prev + 1);
    }, 1000);
  };

  const stopRecording = () => {
    if (recordingIntervalRef.current) {
      clearInterval(recordingIntervalRef.current);
      recordingIntervalRef.current = null;
    }
    setIsRecording(false);

    // Simulate transcribing a speech input using sample text
    setIsTranslating(true);
    setTimeout(() => {
      const sourceIsEnglish = sourceLang.includes('English') || sourceLang.includes('US');
      const sourceIsArabic = sourceLang.includes('Arabic') || sourceLang.includes('AR');
      
      let sampleSpokenText = '';
      if (sourceIsArabic) {
        sampleSpokenText = 'نحن بحاجة إلى الاتفاق على مخرجات المشروع على الفور قبل مراجعة مجلس الإدارة.';
      } else if (sourceIsEnglish) {
        sampleSpokenText = '"We need to align on the project deliverables immediately before the board review."';
      } else {
        sampleSpokenText = '「役員会議の前に、プロジェクトの成果物について大至急合意を形成する必要があります。」';
      }
      
      setSourceText(sampleSpokenText);
      handleTranslate(sampleSpokenText);
    }, 400);
  };

  // Copy helpers
  const copyText = (text: string, isInput: boolean) => {
    navigator.clipboard.writeText(text);
    if (isInput) {
      setCopiedInput(true);
      setTimeout(() => setCopiedInput(false), 2000);
    } else {
      setCopiedOutput(true);
      setTimeout(() => setCopiedOutput(false), 2000);
    }
  };

  // Save to Notes History
  const saveToNotes = () => {
    if (!sourceText.trim() || !translatedText.trim()) return;

    const newNote: Note = {
      id: Date.now().toString(),
      sourceText,
      translatedText,
      sourceLang,
      targetLang,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    };

    const updated = [newNote, ...savedNotes];
    setSavedNotes(updated);
    localStorage.setItem('lingua_ai_notes', JSON.stringify(updated));
  };

  // Handle Chat message submissions
  const handleSendChatMessage = async (e?: React.FormEvent, messageOverride?: string, attachmentsOverride?: ChatAttachment[]) => {
    if (e) e.preventDefault();
    const finalInput = messageOverride || chatInput;
    // Allow sending message if we have attachments even if text is empty
    if (!finalInput.trim() && (!attachmentsOverride || attachmentsOverride.length === 0)) return;

    if (subStatus === 'expired') {
      setErrorMessage("انتهت الفترة التجريبية المجانية! يرجى الترقية إلى الباقة المميزة لمتابعة استخدام الدردشة اللغوية والمترجم الذكي.");
      setIsPaymentModalOpen(true);
      return;
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString() + '-user',
      role: 'user',
      text: finalInput,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      persona: chatPersona,
      attachments: attachmentsOverride || []
    };

    setChatMessages(prev => [...prev, userMessage]);
    setChatInput('');
    setIsChatLoading(true);
    setErrorMessage(null);

    // If offline, simulate a fast professional response!
    if (isOffline) {
      setTimeout(() => {
        let simulatedReply = '';
        const hasAttached = userMessage.attachments && userMessage.attachments.length > 0;
        const attachmentTextAr = hasAttached ? " لقد لاحظت أنك قمت بإرفاق وسائط (صورة/فيديو) أيضاً." : "";
        const attachmentTextEn = hasAttached ? " I noticed you also attached media (image/video)." : "";

        if (chatPersona === 'expert') {
          simulatedReply = `[عملية غير متصلة بالإنترنت • Offline Mode]\n\nبصفتي خبيراً لغوياً، قمت بتحليل جملتك: "${userMessage.text}".${attachmentTextAr} في وضع عدم الاتصال، نقترح استخدام تراكيب نحوية قياسية وتجنب التعابير المعقدة لضمان أقصى درجات الوضوح.\n\nAs a linguistic expert, I analyzed your phrase in offline mode.${attachmentTextEn} For formal contexts, we recommend sticking to highly standardized grammatical patterns and explicit terminology.`;
        } else if (chatPersona === 'advisor') {
          simulatedReply = `[عملية غير متصلة بالإنترنت • Offline Mode]\n\nاقتراح صياغة مهنية:\nعزيزي الشريك،\nنشكركم على تواصلكم. بخصوص "${userMessage.text}"،${attachmentTextAr} نقترح المتابعة فوراً لضمان تناسق مخرجات المشروع.\n\nProfessional drafting proposal:\nDear Partner,\nThank you for reaching out. Regarding "${userMessage.text}",${attachmentTextEn} we recommend aligning immediately to guarantee project deliverables.`;
        } else if (chatPersona === 'cultural') {
          simulatedReply = `[عملية غير متصلة بالإنترنت • Offline Mode]\n\nفي سياق الثقافة المهنية، تذكر دائماً البدء بالتحية المهذبة (مثل: "طاب يومكم" أو استخدام صيغة الجمع للتكريم). بالنسبة لمصطلح "${userMessage.text}"،${attachmentTextAr} يُفضل التعبير عنه بلطف وتواضع.\n\nIn polite professional etiquette, always begin with a respectful greeting. Ensure any request is phrased with humble honorifics to build deep trust.${attachmentTextEn}`;
        } else {
          simulatedReply = `[عملية غير متصلة بالإنترنت • Offline Mode]\n\nأهلاً بك! دعنا نتمرن معاً على المحادثات المهنية. جملتك كانت رائعة!${attachmentTextAr} كيف تفضل صياغتها لتكون أكثر ملاءمة لاجتماعات مجلس الإدارة؟\n\nWelcome! Let's practice professional speaking. Your input is excellent!${attachmentTextEn} How would you like to refine it to make it sound even more board-ready?`;
        }

        const wantsImage = /صورة|صور|صوره|image|picture|photo/i.test(userMessage.text);
        if (wantsImage) {
          let cleanPrompt = userMessage.text.replace(/أريد|اريد|صورة|صور|صوره|لـ|ل|of|image|picture|photo|generate|create|show|me/gi, '').trim();
          if (!cleanPrompt) cleanPrompt = 'beautiful creative artwork';
          simulatedReply += `\n\n![${cleanPrompt}](https://image.pollinations.ai/prompt/${encodeURIComponent(cleanPrompt)}?width=1024&height=1024&nologo=true)`;
        }

        const assistantMessage: ChatMessage = {
          id: Date.now().toString() + '-ai',
          role: 'assistant',
          text: simulatedReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          persona: chatPersona
        };

        setChatMessages(prev => [...prev, assistantMessage]);
        setIsChatLoading(false);
      }, 700);
      return;
    }

    try {
      // Get recent chat history to pass to the model
      const historyToSend = chatMessages
        .slice(-10)
        .map(msg => ({
          role: msg.role,
          text: msg.text,
          attachments: msg.attachments || []
        }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage.text,
          history: historyToSend,
          persona: chatPersona,
          attachments: userMessage.attachments
        })
      });

      if (!response.ok) {
        throw new Error('Failed to fetch response from AI Chat server');
      }

      const data = await response.json();
      
      const assistantMessage: ChatMessage = {
        id: Date.now().toString() + '-ai',
        role: 'assistant',
        text: data.text || 'Sorry, I could not generate a response.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        persona: chatPersona
      };

      setChatMessages(prev => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('Chat error:', err);
      setErrorMessage(err.message || 'Error communicating with the chat assistant.');
    } finally {
      setIsChatLoading(false);
    }
  };

  // Speaks chat response out loud using SpeechSynthesis
  const speakChatMessage = (message: ChatMessage) => {
    try {
      const synth = window.speechSynthesis;
      if (!synth) {
        console.warn('Speech synthesis not supported in this browser.');
        return;
      }

      // Stop any existing speech first
      synth.cancel();

      if (currentlySpeakingMessageId === message.id) {
        setCurrentlySpeakingMessageId(null);
        return;
      }

      setCurrentlySpeakingMessageId(message.id);

      // Clean the text from any markdown images or links to make the reading crystal clear and realistic
      let cleanText = message.text;
      
      // Remove Pollinations AI or general images
      cleanText = cleanText.replace(/!\[.*?\]\(.*?\)/g, '');
      // Remove link markdowns
      cleanText = cleanText.replace(/\[(.*?)\]\(.*?\)/g, '$1');
      // Remove asterisks
      cleanText = cleanText.replace(/\*+/g, '');
      
      const utterance = new SpeechSynthesisUtterance(cleanText);
      
      // Smartly detect language of the message
      const hasArabic = /[\u0600-\u06FF]/.test(cleanText);
      
      // Smartly find the best matching voice by language and gender
      const voices = synth.getVoices();
      const persona = message.persona || 'expert';
      const isFemale = persona === 'expert' || persona === 'cultural';
      
      let selectedVoice = null;
      if (hasArabic) {
        utterance.lang = 'ar-SA';
        // Arabic voices (often gender-specific by name, e.g., 'Hoda', 'Naaman', 'Zeina', 'Maged', 'Tarik', 'Laila')
        const arVoices = voices.filter(v => v.lang.startsWith('ar') || v.lang.includes('ar-'));
        if (isFemale) {
          selectedVoice = arVoices.find(v => v.name.toLowerCase().includes('hoda') || v.name.toLowerCase().includes('zeina') || v.name.toLowerCase().includes('laila') || v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('google') || v.name.toLowerCase().includes('arabic'));
        } else {
          selectedVoice = arVoices.find(v => v.name.toLowerCase().includes('naaman') || v.name.toLowerCase().includes('maged') || v.name.toLowerCase().includes('tarik') || v.name.toLowerCase().includes('male'));
        }
        if (!selectedVoice) selectedVoice = arVoices[0]; // fallback
      } else {
        utterance.lang = 'en-US';
        // English voices
        const enVoices = voices.filter(v => v.lang.startsWith('en') || v.lang.includes('en-'));
        if (isFemale) {
          selectedVoice = enVoices.find(v => v.name.toLowerCase().includes('samantha') || v.name.toLowerCase().includes('zira') || v.name.toLowerCase().includes('hazel') || v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('google us english') || v.name.toLowerCase().includes('english'));
        } else {
          selectedVoice = enVoices.find(v => v.name.toLowerCase().includes('david') || v.name.toLowerCase().includes('mark') || v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('google uk english male'));
        }
        if (!selectedVoice) selectedVoice = enVoices[0]; // fallback
      }

      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }

      // Customize voice pitch based on the character persona for ultimate realism and distinct personality!
      if (persona === 'expert') {
        utterance.pitch = 1.05; // slightly higher intellectual female voice (Dr. Layla)
      } else if (persona === 'advisor') {
        utterance.pitch = 0.90; // authoritative, deeper male voice (Tariq)
      } else if (persona === 'cultural') {
        utterance.pitch = 0.98; // gentle, warm, balanced female voice (Amina)
      } else if (persona === 'trainer') {
        utterance.pitch = 1.10; // friendly, cheerful, upbeat male voice (Ryan)
      }
      
      // Use the playback speed rate slider!
      utterance.rate = playbackSpeed;

      utterance.onend = () => {
        setCurrentlySpeakingMessageId(null);
      };

      utterance.onerror = (event) => {
        console.error('Speech Utterance Error:', event);
        setCurrentlySpeakingMessageId(null);
      };

      synth.speak(utterance);
    } catch (e) {
      console.error('Speech synthesis failure:', e);
      setCurrentlySpeakingMessageId(null);
    }
  };

  // Stop reading chat response
  const stopSpeakingChatMessage = () => {
    try {
      window.speechSynthesis.cancel();
    } catch (e) {}
    setCurrentlySpeakingMessageId(null);
  };

  // Clear Chat messages
  const clearChatHistory = () => {
    setChatMessages([
      {
        id: 'welcome',
        role: 'assistant',
        text: "تم مسح المحادثة. كيف يمكنني مساعدتك الآن؟\n\nChat history cleared. How can I assist you now?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        persona: chatPersona
      }
    ]);
    showChatToast("Chat history cleared • تم مسح سجل الدردشة");
  };

  // Delete note
  const deleteNote = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedNotes.filter(n => n.id !== id);
    setSavedNotes(updated);
    localStorage.setItem('lingua_ai_notes', JSON.stringify(updated));
  };

  // Load selected note
  const loadNote = (note: Note) => {
    setSourceLang(note.sourceLang);
    setTargetLang(note.targetLang);
    setSourceText(note.sourceText);
    setTranslatedText(note.translatedText);
    setShowHistoryOnly(false);
  };

  // Process subscription payment
  const handleProcessPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessingPayment(true);
    setTimeout(() => {
      setIsProcessingPayment(false);
      setPaymentSuccess(true);
      setSubStatus('premium');
      setErrorMessage(null); // Clear trial expired errors if any
    }, 2200);
  };

  // Close payment modal and reset states
  const closePaymentModal = () => {
    setIsPaymentModalOpen(false);
    setPaymentSuccess(false);
    setCardNumber('');
    setCardExpiry('');
    setCardCvv('');
    setCardHolder('');
  };

  // Format time display
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remaining = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remaining.toString().padStart(2, '0')}`;
  };

  if (activeTab === 'chat') {
    return (
      <GeminiChat
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        chatPersona={chatPersona}
        setChatPersona={setChatPersona}
        chatMessages={chatMessages}
        setChatMessages={setChatMessages}
        chatInput={chatInput}
        setChatInput={setChatInput}
        isChatLoading={isChatLoading}
        currentlySpeakingMessageId={currentlySpeakingMessageId}
        speakChatMessage={speakChatMessage}
        stopSpeakingChatMessage={stopSpeakingChatMessage}
        clearChatHistory={clearChatHistory}
        handleSendChatMessage={handleSendChatMessage}
        playbackSpeed={playbackSpeed}
        setPlaybackSpeed={setPlaybackSpeed}
        subStatus={subStatus}
        setSubStatus={setSubStatus}
        trialDaysRemaining={trialDaysRemaining}
        setTrialDaysRemaining={setTrialDaysRemaining}
        isPaymentModalOpen={isPaymentModalOpen}
        setIsPaymentModalOpen={setIsPaymentModalOpen}
        isRecording={isRecording}
        setIsRecording={setIsRecording}
        errorMessage={errorMessage}
        setErrorMessage={setErrorMessage}
        chatToast={chatToast}
        showChatToast={showChatToast}
        renderFormattedText={renderFormattedText}
        closePaymentModal={closePaymentModal}
        handleProcessPayment={handleProcessPayment}
        selectedPayment={selectedPayment}
        setSelectedPayment={setSelectedPayment}
        cardHolder={cardHolder}
        setCardHolder={setCardHolder}
        cardNumber={cardNumber}
        setCardNumber={setCardNumber}
        cardExpiry={cardExpiry}
        setCardExpiry={setCardExpiry}
        cardCvv={cardCvv}
        setCardCvv={setCardCvv}
        isProcessingPayment={isProcessingPayment}
        paymentSuccess={paymentSuccess}
      />
    );
  }

  return (
    <div id="app" className="min-h-screen bg-[#080808] text-white font-sans antialiased selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Container matching full layout limits */}
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 flex flex-col min-h-screen">
        
        {/* Header Block */}
        <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8 pb-6 border-b border-[#222222]">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600/10 p-2.5 rounded-xl border border-indigo-500/20 shadow-[0_0_15px_rgba(99,102,241,0.15)]">
              <Languages className="w-6 height-6 text-[#818cf8]" />
            </div>
            <div>
              <h1 className="font-serif italic text-2xl font-bold tracking-tight text-white flex items-center gap-1.5">
                LINGUA<span className="text-[#818cf8] font-sans text-xl not-italic font-extrabold">·</span>AI
              </h1>
              <p className="text-[11px] text-zinc-500 font-mono tracking-widest uppercase">Sophisticated Neural Engine</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-xs text-zinc-400">
            {/* Live active engine badge */}
            <div className="flex items-center gap-2 bg-zinc-900/80 px-3 py-1.5 rounded-full border border-zinc-800">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#818cf8] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#818cf8]"></span>
              </span>
              <span className="font-mono tracking-wide text-zinc-300">Neural Engine Active</span>
            </div>

            <div className="bg-zinc-900/40 px-3 py-1.5 rounded-full border border-zinc-850/50">
              <span className="text-zinc-500 font-mono">{locationStr}</span>
              <span className="mx-2 text-zinc-700">•</span>
              <span className="font-mono text-[#818cf8]">{currentTime || 'July 1, 2026 • 18:47'}</span>
            </div>
          </div>
        </header>

        {/* Subscription Status & Simulator Banner */}
        <div className="mb-6">
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`border rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-all duration-300 ${
              subStatus === 'premium' 
                ? 'bg-emerald-950/15 border-emerald-500/30 shadow-[0_4px_20px_rgba(16,185,129,0.05)]' 
                : subStatus === 'expired'
                ? 'bg-rose-950/15 border-rose-500/30 shadow-[0_4px_20px_rgba(244,63,94,0.05)] animate-pulse'
                : 'bg-indigo-950/15 border-indigo-500/30 shadow-[0_4px_20px_rgba(99,102,241,0.05)]'
            }`}
          >
            {/* Status Information */}
            <div className="flex items-start gap-4 w-full md:w-auto">
              <div className={`p-3 rounded-xl border shrink-0 ${
                subStatus === 'premium' 
                  ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                  : subStatus === 'expired'
                  ? 'bg-rose-500/10 border-rose-500/20 text-rose-400'
                  : 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400'
              }`}>
                {subStatus === 'premium' ? (
                  <Award className="w-6 h-6 animate-bounce" />
                ) : subStatus === 'expired' ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Calendar className="w-6 h-6" />
                )}
              </div>

              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <span className={`text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                    subStatus === 'premium' 
                      ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/30' 
                      : subStatus === 'expired'
                      ? 'bg-rose-950/40 text-rose-400 border-rose-800/30'
                      : 'bg-indigo-950/40 text-indigo-400 border-indigo-800/30'
                  }`}>
                    {subStatus === 'premium' ? 'Premium Active • باقة التميّز' : subStatus === 'expired' ? 'Trial Expired • انتهت التجربة' : 'Free Trial • فترة تجريبية مجانية'}
                  </span>

                  {subStatus === 'trial' && (
                    <span className="text-zinc-500 text-xs font-mono">
                      (1-Week Free Trial • أسبوع تجربة مجانية)
                    </span>
                  )}
                </div>

                {subStatus === 'premium' ? (
                  <div>
                    <h3 className="font-serif italic text-lg text-white">
                      Premium Subscription Active • الاشتراك المميّز نشط
                    </h3>
                    <p className="text-zinc-400 text-xs mt-1 leading-relaxed">
                      Enjoy unlimited high-speed translations for <strong className="text-emerald-400">2 Months ($25)</strong>. Thank you for your support!
                      <span className="block text-zinc-500 text-[11px] dir-rtl text-right mt-0.5">
                        اشتراك مميّز غير محدود <strong className="text-emerald-400">لمدة شهرين (بقيمة ٢٥ دولار)</strong>. شكراً لدعمك لخدماتنا!
                      </span>
                    </p>
                  </div>
                ) : subStatus === 'expired' ? (
                  <div>
                    <h3 className="font-serif italic text-lg text-rose-300">
                      Your 1-Week Free Trial has Expired • انتهى أسبوعك المجاني
                    </h3>
                    <p className="text-zinc-400 text-xs mt-1 leading-relaxed">
                      Upgrade now to Premium for just <strong className="text-indigo-400">$25 for 2 months</strong> to restore full access.
                      <span className="block text-zinc-500 text-[11px] dir-rtl text-right mt-0.5">
                        يرجى الترقية للباقة المميزة فقط <strong className="text-[#818cf8]">بقيمة ٢٥ دولار لمدة شهرين</strong> لاستعادة إمكانية الترجمة.
                      </span>
                    </p>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-serif italic text-lg text-white">
                        {trialDaysRemaining} Days Remaining • متبقي {trialDaysRemaining} أيام في التجربة
                      </h3>
                      <span className="text-indigo-400 text-xs font-semibold">({7 - trialDaysRemaining}/7 days used)</span>
                    </div>
                    
                    {/* Progress Bar */}
                    <div className="w-full bg-zinc-900 h-1.5 rounded-full mt-2 border border-zinc-800 overflow-hidden max-w-sm">
                      <div 
                        className="bg-indigo-500 h-full rounded-full transition-all duration-300"
                        style={{ width: `${(trialDaysRemaining / 7) * 100}%` }}
                      />
                    </div>

                    <p className="text-zinc-400 text-xs mt-1.5 leading-relaxed">
                      Enjoy 1 week of free access. After that, upgrade for just <strong className="text-indigo-400">$25 for 2 months</strong>.
                      <span className="block text-zinc-500 text-[11px] dir-rtl text-right mt-0.5">
                        استمتع بأسبوع مجاني كامل. بعد ذلك، يمكنك الترقية مقابل <strong className="text-[#818cf8]">٢٥ دولار فقط لمدة شهرين</strong>.
                      </span>
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Actions & Simulation Sandbox */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto shrink-0 border-t border-zinc-900 md:border-t-0 pt-3 md:pt-0">
              
              {/* Simulator Toolbox */}
              <div className="flex items-center gap-1.5 justify-center bg-zinc-950/60 p-1.5 rounded-xl border border-zinc-850/50">
                <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest px-1">TEST:</span>
                
                {subStatus === 'trial' && (
                  <>
                    <button 
                      onClick={() => setTrialDaysRemaining(prev => Math.max(0, prev - 1))}
                      disabled={trialDaysRemaining === 0}
                      className="text-[10px] bg-zinc-900 hover:bg-zinc-850 text-zinc-400 hover:text-white px-2 py-1 rounded border border-zinc-800 transition-colors cursor-pointer disabled:opacity-50"
                      title="Simulate 1 Day passing"
                    >
                      -1 Day
                    </button>
                    <button 
                      onClick={() => {
                        setTrialDaysRemaining(0);
                        setSubStatus('expired');
                        setErrorMessage("انتهت الفترة التجريبية المجانية! يرجى الترقية إلى الباقة المميزة لمتابعة استخدام محرك الترجمة الذكي.");
                      }}
                      className="text-[10px] bg-red-950/30 hover:bg-red-900/40 text-red-400 hover:text-red-300 px-2 py-1 rounded border border-red-900/30 transition-colors cursor-pointer"
                      title="Expire trial instantly"
                    >
                      Expire Trial
                    </button>
                  </>
                )}

                {(subStatus === 'premium' || subStatus === 'expired') && (
                  <button 
                    onClick={() => {
                      setSubStatus('trial');
                      setTrialDaysRemaining(7);
                      setErrorMessage(null);
                    }}
                    className="text-[10px] bg-zinc-900 hover:bg-zinc-850 text-zinc-400 hover:text-white px-2 py-1 rounded border border-zinc-800 transition-colors cursor-pointer"
                    title="Reset to free trial mode"
                  >
                    Reset to Trial
                  </button>
                )}
              </div>

              {/* Upgrade Button */}
              {subStatus !== 'premium' ? (
                <button
                  onClick={() => setIsPaymentModalOpen(true)}
                  className="bg-[#818cf8] text-zinc-950 hover:bg-indigo-300 px-4 py-2.5 rounded-xl text-xs font-mono font-bold tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-[0_4px_15px_rgba(129,140,248,0.25)] hover:scale-102"
                >
                  <CreditCard className="w-4 h-4 text-zinc-950" />
                  Upgrade • ترقية
                </button>
              ) : (
                <button
                  onClick={() => setIsPaymentModalOpen(true)}
                  className="bg-emerald-500/10 hover:bg-emerald-500/15 border border-emerald-500/20 text-emerald-400 px-4 py-2.5 rounded-xl text-xs font-mono font-bold tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Details • التفاصيل
                </button>
              )}

            </div>
          </motion.div>
        </div>

        {/* Errors Container */}
        {errorMessage && (
          <div className="mb-6 p-4 bg-red-950/25 border border-red-900/40 text-red-200 rounded-xl text-sm flex items-start gap-3">
            <Info className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">AI Assistant Alert</p>
              <p className="text-zinc-400 text-xs mt-1">{errorMessage}</p>
            </div>
          </div>
        )}

        {/* Navigation Tabs (Translate vs Chat) */}
        {!showHistoryOnly && (
          <div className="flex border-b border-zinc-850 mb-6 gap-2">
            <button
              onClick={() => setActiveTab('translate')}
              className={`pb-3 px-6 text-xs sm:text-sm font-medium transition-all relative flex items-center gap-2 cursor-pointer ${
                activeTab === 'translate'
                  ? 'text-white border-b-2 border-[#818cf8] font-semibold'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              <Languages className="w-4 h-4" />
              <span>Translator • محرك الترجمة</span>
            </button>
            <button
              onClick={() => setActiveTab('chat')}
              className={`pb-3 px-6 text-xs sm:text-sm font-medium transition-all relative flex items-center gap-2 cursor-pointer ${
                activeTab === 'chat'
                  ? 'text-white border-b-2 border-[#818cf8] font-semibold'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              <MessagesSquare className="w-4 h-4 text-[#818cf8]" />
              <span className="flex items-center gap-1.5">
                AI Interactive Chat • الدردشة اللغوية الذكية
                <span className="bg-indigo-500/10 text-indigo-400 font-mono text-[9px] px-1.5 py-0.5 rounded border border-indigo-500/20 uppercase tracking-widest font-bold hidden sm:inline-block">New</span>
              </span>
            </button>
          </div>
        )}

        {/* Secondary View Tab for saved history log */}
        {showHistoryOnly ? (
          <div className="flex-1 flex flex-col bg-[#121212] border border-[#222222] rounded-2xl p-6 sm:p-8 animate-fade-in">
            <div className="flex justify-between items-center mb-6 pb-4 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-[#818cf8]" />
                <h2 className="text-lg font-serif">Saved Translation History ({savedNotes.length})</h2>
              </div>
              <button 
                onClick={() => setShowHistoryOnly(false)}
                className="text-zinc-400 hover:text-white text-xs bg-zinc-900 px-3 py-1.5 rounded-lg border border-zinc-800 transition-colors"
              >
                Back to Workspace
              </button>
            </div>

            {savedNotes.length === 0 ? (
              <div className="flex-1 flex flex-col justify-center items-center text-zinc-500 py-12">
                <History className="w-12 h-12 text-zinc-700 mb-3" />
                <p className="text-zinc-400 font-serif italic text-lg">No saved notes yet</p>
                <p className="text-zinc-600 text-xs mt-1">Translations you save will appear here for easy recall.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 overflow-y-auto max-h-[500px] pr-2">
                {savedNotes.map(note => (
                  <div 
                    key={note.id}
                    onClick={() => loadNote(note)}
                    className="bg-[#0f0f12] border border-zinc-800 hover:border-zinc-700 p-5 rounded-xl cursor-pointer transition-all duration-200 group flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex justify-between items-start mb-3">
                        <span className="text-[10px] uppercase font-mono tracking-wider bg-zinc-900 text-zinc-400 px-2 py-0.5 rounded border border-zinc-800">
                          {note.sourceLang} → {note.targetLang}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-zinc-500 font-mono">{note.timestamp}</span>
                          <button 
                            onClick={(e) => deleteNote(note.id, e)}
                            className="text-zinc-600 hover:text-red-400 p-1 rounded hover:bg-zinc-800/50 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <p className="text-sm text-zinc-300 font-serif italic line-clamp-2 mb-2">"{note.sourceText}"</p>
                      <p className="text-sm text-white font-serif line-clamp-2">「{note.translatedText}」</p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-zinc-900 text-[11px] text-[#818cf8] flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <span>Load into workspace</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : activeTab === 'translate' ? (
          /* Main Workspace Layout (Left grid, Right Sidebar) */
          <div className="grid grid-cols-1 lg:grid-template-cols-12 lg:grid-cols-12 gap-8 flex-1 items-stretch">
            
            {/* Left side: The Translation Workspace (8/12 cols) */}
            <div className="lg:col-span-8 flex flex-col gap-6">
              
              {/* Presets Row */}
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="flex flex-wrap items-center gap-2"
              >
                <span className="text-[10px] uppercase font-mono tracking-wider text-zinc-500 mr-2 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-indigo-400" /> Presets:
                </span>
                {quickPresets.map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setSourceText(p.text);
                      handleTranslate(p.text);
                    }}
                    className="text-xs bg-zinc-900/60 hover:bg-zinc-900 border border-zinc-850 hover:border-zinc-800 px-3 py-1.5 rounded-lg text-zinc-400 hover:text-white transition-all cursor-pointer"
                  >
                    {p.label}
                  </button>
                ))}
              </motion.div>

              {/* Source Language Card */}
              <motion.div 
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="bg-[#121212] border border-[#222222] rounded-2xl p-6 relative flex flex-col shadow-[0_4px_30px_rgba(0,0,0,0.5)]"
              >
                
                {/* Language Indicator & Controls */}
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xs uppercase tracking-widest font-mono text-zinc-500">Source Text</span>
                    <div className="relative">
                      <select 
                        value={sourceLang} 
                        onChange={(e) => setSourceLang(e.target.value)}
                        className="bg-zinc-900 border border-zinc-800 text-zinc-300 text-xs px-2.5 py-1 rounded-lg focus:outline-none focus:border-indigo-500 cursor-pointer pr-6 appearance-none"
                      >
                        <option value="English (US)">English (US)</option>
                        <option value="Arabic (AR)">Arabic (AR)</option>
                        <option value="Japanese (JP)">Japanese (JP)</option>
                        <option value="Spanish (ES)">Spanish (ES)</option>
                        <option value="French (FR)">French (FR)</option>
                        <option value="German (DE)">German (DE)</option>
                        <option value="Chinese (ZH)">Chinese (ZH)</option>
                      </select>
                      <ChevronDown className="w-3 h-3 text-zinc-500 absolute right-2 top-2.5 pointer-events-none" />
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button 
                      onClick={swapLanguages} 
                      className="p-1.5 rounded-lg bg-zinc-900/80 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700 transition-colors"
                      title="Swap Source & Target Languages"
                    >
                      <ArrowLeftRight className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => copyText(sourceText, true)}
                      className="p-1.5 rounded-lg bg-zinc-900/80 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700 transition-colors"
                      title="Copy Source Text"
                    >
                      {copiedInput ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Main Text Input Area */}
                <div className="relative w-full">
                  <textarea
                    value={sourceText}
                    onChange={(e) => setSourceText(e.target.value)}
                    placeholder="Type or paste your text here..."
                    className={`w-full bg-transparent text-white font-serif italic text-xl md:text-2xl leading-relaxed focus:outline-none resize-none min-h-[140px] border-b border-[#222222] pb-4 ${isSourceArabic ? 'text-right pl-10' : 'text-left pr-10'}`}
                    dir={isSourceArabic ? 'rtl' : 'ltr'}
                  />
                  {sourceText && (
                    <button
                      onClick={() => setSourceText('')}
                      className={`absolute top-1 ${isSourceArabic ? 'left-1' : 'right-1'} p-1.5 rounded-full bg-zinc-900/40 text-zinc-400 hover:text-white hover:bg-zinc-800/80 transition-colors cursor-pointer`}
                      title="Clear text"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Bottom Card Controls: Interactive Audio Wave and Action Trigger */}
                <div className="flex justify-between items-center mt-4">
                  <div className="flex items-center gap-3">
                    {/* Visual Waveform */}
                    <div className="waveform flex items-center gap-1.5 h-6">
                      {waveHeights.slice(0, 7).map((h, i) => (
                        <div 
                          key={i} 
                          className="bar w-[3px] bg-[#818cf8] rounded-full opacity-60 transition-all duration-150"
                          style={{ height: `${h * 0.25}px` }}
                        />
                      ))}
                    </div>
                    {isRecording && (
                      <span className="text-xs text-red-400 font-mono animate-pulse">
                        Listening... {formatTime(recordingSeconds)}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-zinc-600 text-[10px] font-mono">
                      {sourceText.length} chars • {sourceText.split(/\s+/).filter(Boolean).length} words
                    </span>
                    <button
                      onClick={() => handleTranslate()}
                      disabled={isTranslating}
                      className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-zinc-800 disabled:text-zinc-600 disabled:border-zinc-900 border border-indigo-500/30 font-semibold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-all text-white shadow-[0_4px_15px_rgba(99,102,241,0.2)] cursor-pointer"
                    >
                      {isTranslating ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          Translating...
                        </>
                      ) : (
                        <>
                          <RefreshCw className="w-3.5 h-3.5" />
                          Translate
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </motion.div>

              {/* Target Language Card */}
              <motion.div 
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.1 }}
                className="bg-[#121212] border border-[#222222] rounded-2xl p-6 flex flex-col relative shadow-[0_4px_30px_rgba(0,0,0,0.5)]"
              >
                
                {/* Language Indicator */}
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xs uppercase tracking-widest font-mono text-zinc-500">Live Translation</span>
                    <div className="relative">
                      <select 
                        value={targetLang} 
                        onChange={(e) => setTargetLang(e.target.value)}
                        className="bg-zinc-900 border border-zinc-800 text-zinc-300 text-xs px-2.5 py-1 rounded-lg focus:outline-none focus:border-indigo-500 cursor-pointer pr-6 appearance-none"
                      >
                        <option value="Japanese (JP)">Japanese (JP)</option>
                        <option value="English (US)">English (US)</option>
                        <option value="Arabic (AR)">Arabic (AR)</option>
                        <option value="Spanish (ES)">Spanish (ES)</option>
                        <option value="French (FR)">French (FR)</option>
                        <option value="German (DE)">German (DE)</option>
                        <option value="Chinese (ZH)">Chinese (ZH)</option>
                      </select>
                      <ChevronDown className="w-3 h-3 text-zinc-500 absolute right-2 top-2.5 pointer-events-none" />
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Settings/Tone Selector */}
                    <div className="flex items-center bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded-lg text-xs text-zinc-400">
                      <span className="text-[10px] uppercase font-mono text-zinc-600 mr-2">Tone:</span>
                      <select
                        value={selectedTone}
                        onChange={(e) => {
                          setSelectedTone(e.target.value);
                          handleTranslate(sourceText, e.target.value);
                        }}
                        className="bg-transparent focus:outline-none text-zinc-300 cursor-pointer"
                      >
                        <option value="Corporate Formal">Corporate Formal</option>
                        <option value="Casual Friendly">Casual Friendly</option>
                        <option value="Humble (Keigo)">Humble (Keigo)</option>
                        <option value="Technical Direct">Technical Direct</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Translation Text Area */}
                <div className="min-h-[140px] border-b border-[#222222] pb-4 flex flex-col justify-between">
                  {isTranslating ? (
                    <div className="flex-1 flex flex-col justify-center items-center py-6">
                      <Loader2 className="w-8 h-8 text-[#818cf8] animate-spin mb-2" />
                      <p className="text-zinc-500 text-xs font-mono animate-pulse">Syncing semantic models...</p>
                    </div>
                  ) : (
                    <p 
                      className={`font-serif text-2xl md:text-3xl text-white leading-relaxed whitespace-pre-line ${isTargetArabic ? 'text-right' : 'text-left'}`}
                      dir={isTargetArabic ? 'rtl' : 'ltr'}
                    >
                      {translatedText || <span className="text-zinc-600 font-sans italic text-base">Translation will appear here...</span>}
                    </p>
                  )}
                </div>

                {/* Translation Assistant Action Bar */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mt-4">
                  <div className="flex flex-wrap gap-2">
                    <button 
                      onClick={() => copyText(translatedText, false)}
                      className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                      title="Copy translated text to clipboard"
                    >
                      {copiedOutput ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>Copy Text</span>
                    </button>
                    <button 
                      onClick={speakTranslation}
                      className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                      title="Speak using Gemini neural TTS"
                    >
                      {isPlayingAudio ? (
                        <>
                          <VolumeX className="w-3.5 h-3.5 text-red-400 animate-pulse" />
                          <span>Stop Audio</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5 text-[#818cf8]" />
                          <span>Speak Audio</span>
                        </>
                      )}
                    </button>
                    <button 
                      onClick={saveToNotes}
                      className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                      title="Save translation to history"
                    >
                      <Save className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Save to Notes</span>
                    </button>

                    {/* Playback Speed Control */}
                    <div className="flex items-center gap-2.5 bg-zinc-900 border border-zinc-800 px-3 py-1 rounded-xl text-xs text-zinc-300 shadow-sm">
                      <div className="flex items-center gap-1.5 shrink-0 select-none">
                        <Gauge className="w-3.5 h-3.5 text-[#818cf8]" />
                        <span className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest">Speed:</span>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <input 
                          type="range"
                          min="0.5"
                          max="1.5"
                          step="0.5"
                          value={playbackSpeed}
                          onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                          className="w-16 accent-indigo-400 h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer focus:outline-none"
                          title="Slide to change audio playback speed"
                        />
                        <span className="font-mono text-[11px] font-bold text-zinc-100 min-w-[28px] text-center">
                          {playbackSpeed}x
                        </span>
                      </div>

                      <div className="flex items-center gap-1 border-l border-zinc-800/80 pl-2">
                        {[0.5, 1, 1.5].map((speed) => (
                          <button
                            key={speed}
                            onClick={() => setPlaybackSpeed(speed)}
                            className={`px-1.5 py-0.5 rounded text-[10px] font-mono transition-colors cursor-pointer ${
                              playbackSpeed === speed 
                                ? 'bg-indigo-500/10 text-[#818cf8] border border-indigo-500/20 font-bold' 
                                : 'text-zinc-500 hover:text-zinc-300 hover:bg-zinc-850 border border-transparent'
                            }`}
                          >
                            {speed}x
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {audioError && (
                    <span className="text-red-400 text-xs font-mono">{audioError}</span>
                  )}
                </div>
              </motion.div>

            </div>

            {/* Right side: AI Smart Assistant Sidebar (4/12 cols) */}
            <div className="lg:col-span-4 flex flex-col gap-6">
              
              {/* Offline & Connectivity Control Center */}
              <motion.div 
                id="offline-manager" 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
                className="bg-[#0f0f12] border border-[#222222] rounded-2xl p-5 flex flex-col gap-4 shadow-[0_4px_30px_rgba(0,0,0,0.5)]"
              >
                <div className="flex items-center justify-between border-b border-[#222222] pb-3">
                  <div className="flex items-center gap-2">
                    {isOffline ? (
                      <WifiOff className="w-4 h-4 text-amber-500 animate-pulse" />
                    ) : (
                      <Wifi className="w-4 h-4 text-[#818cf8]" />
                    )}
                    <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-400">Offline Connectivity</h3>
                  </div>
                  <button
                    onClick={() => {
                      setIsOffline(prev => !prev);
                      setErrorMessage(null);
                    }}
                    className={`px-3 py-1 rounded-full text-[11px] font-mono border transition-all cursor-pointer font-bold ${
                      isOffline
                        ? "bg-amber-500/10 text-amber-500 border-amber-500/30"
                        : "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                    }`}
                  >
                    {isOffline ? "OFFLINE MODE" : "ONLINE (GEMINI)"}
                  </button>
                </div>

                <div className="text-xs text-zinc-400 leading-relaxed bg-zinc-950/40 p-3 rounded-xl border border-zinc-900 flex items-start gap-2.5">
                  <HardDrive className="w-4 h-4 text-[#818cf8] mt-0.5 shrink-0" />
                  <div>
                    <span className="text-zinc-300 font-semibold block mb-0.5">Secure Local Sandbox</span>
                    Toggle offline mode to process translations, custom tones, glossary keywords, and context insights entirely on-device. Perfect for deep data residency.
                  </div>
                </div>

                {/* Pack Downloaders */}
                <div className="flex flex-col gap-2.5">
                  <div className="flex justify-between items-center text-[10px] font-mono text-zinc-500 uppercase tracking-wider">
                    <span>Language Packs</span>
                    <span>
                      {languagePacks.filter(p => p.downloaded).length} / {languagePacks.length} Stored
                    </span>
                  </div>

                  <div className="flex flex-col gap-2 max-h-[195px] overflow-y-auto pr-1">
                    {languagePacks.map(pack => (
                      <div
                        key={pack.id}
                        className="bg-zinc-900/40 border border-zinc-850 p-2.5 rounded-xl flex flex-col gap-2 transition-all hover:border-zinc-800"
                      >
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-zinc-700" style={{ backgroundColor: pack.downloaded ? '#10b981' : pack.isDownloading ? '#f59e0b' : '#3f3f46' }}></span>
                            <div>
                              <span className="text-xs font-medium text-zinc-200 block">{pack.name}</span>
                              <span className="text-[10px] text-zinc-500 font-mono">
                                {pack.sizeMB} MB • {pack.wordCount.toLocaleString()} tokens
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5">
                            {pack.downloaded ? (
                              <div className="flex items-center gap-1">
                                <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/15">
                                  Ready
                                </span>
                                {pack.id !== 'en-us' && pack.id !== 'ja-jp' && (
                                  <button
                                    onClick={() => deleteLanguagePack(pack.id)}
                                    className="p-1 rounded text-zinc-500 hover:text-red-400 hover:bg-zinc-800/50 transition-colors cursor-pointer"
                                    title="Delete pack"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            ) : pack.isDownloading ? (
                              <div className="flex items-center gap-1.5">
                                <Loader2 className="w-3.5 h-3.5 text-amber-500 animate-spin" />
                                <span className="text-[10px] text-amber-500 font-mono font-bold">{pack.downloadProgress}%</span>
                              </div>
                            ) : (
                              <button
                                onClick={() => downloadLanguagePack(pack.id)}
                                className="bg-zinc-800 hover:bg-[#818cf8] text-zinc-300 hover:text-white border border-zinc-750 hover:border-[#6366f1] p-1.5 rounded-lg transition-all cursor-pointer"
                                title="Download Language Pack"
                              >
                                <Download className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>

                        {pack.isDownloading && (
                          <div className="w-full bg-zinc-950 h-1.5 rounded-full overflow-hidden border border-zinc-900">
                            <div
                              className="bg-amber-500 h-full rounded-full transition-all duration-150"
                              style={{ width: `${pack.downloadProgress}%` }}
                            ></div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
              
              {/* Main AI Smart Assistant panel */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.1 }}
                className="bg-[#0f0f12] border border-[#222222] rounded-2xl p-6 flex flex-col gap-5 shadow-[0_4px_30px_rgba(0,0,0,0.5)]"
              >
                
                <div className="flex items-center justify-between border-b border-[#222222] pb-3">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#818cf8]" />
                    <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-400">AI Smart Assistant</h3>
                  </div>
                  <div className="bg-[#818cf8]/10 text-[#818cf8] font-mono text-[9px] px-2 py-0.5 rounded-full border border-[#818cf8]/20 uppercase">
                    {toneDetected}
                  </div>
                </div>

                {/* Assistant Message */}
                <div className="bg-indigo-950/10 border-l-2 border-[#818cf8] p-4 rounded-r-xl">
                  <p className="text-xs text-zinc-300 leading-relaxed font-sans">
                    {toneExplanation || "Start translating or speaking to activate context analysis."}
                  </p>
                </div>

                {/* Suggestions Chips */}
                <div className="flex flex-col gap-2">
                  <span className="text-[10px] uppercase font-mono text-zinc-500 tracking-wider">Suggested Actions</span>
                  <div className="flex flex-wrap gap-2">
                    {suggestions.map((chip, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSuggestionAction(chip)}
                        className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-850 px-3 py-1.5 rounded-lg text-xs cursor-pointer text-[#818cf8] hover:text-white font-medium transition-colors"
                      >
                        {chip}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Context Insights */}
                {contextInsights.length > 0 && (
                  <div className="flex flex-col gap-2.5 mt-2">
                    <span className="text-[10px] uppercase font-mono text-zinc-500 tracking-wider">Context Insights</span>
                    <div className="flex flex-col gap-2 text-xs leading-relaxed text-zinc-400 bg-zinc-900/30 p-3.5 rounded-xl border border-zinc-850">
                      {contextInsights.map((insight, idx) => (
                        <div key={idx} className="flex gap-2">
                          <span className="text-[#818cf8] select-none">•</span>
                          <p>{insight}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>

              {/* Dynamic terminology definitions panel when requested */}
              {definitions.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className="bg-[#0f0f12] border border-[#222222] rounded-2xl p-6 flex flex-col gap-4 shadow-[0_4px_30px_rgba(0,0,0,0.5)]"
                >
                  <div className="flex items-center gap-2 border-b border-[#222222] pb-3">
                    <BookOpen className="w-4 h-4 text-emerald-400" />
                    <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-400">Smart Glossary</h3>
                  </div>
                  <div className="flex flex-col gap-3">
                    {definitions.map((def, idx) => (
                      <div key={idx} className="bg-zinc-900/50 p-3 rounded-lg border border-zinc-850">
                        <div className="flex justify-between items-center mb-1">
                          <span className="font-serif font-bold text-sm text-white">{def.term}</span>
                          <span className="text-xs font-serif text-emerald-400 font-bold">{def.translation}</span>
                        </div>
                        <p className="text-xs text-zinc-400 leading-normal font-sans">{def.explanation}</p>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        ) : (
          /* AI Interactive Chat Room layout */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 flex-1 items-stretch animate-fade-in">
            
            {/* Left Column: Chat Personas & Speaking Settings */}
            <div className="lg:col-span-4 flex flex-col gap-5 animate-fade-in">
              
              {/* ChatGPT-style Start New Chat Button */}
              <button
                type="button"
                onClick={() => {
                  const welcomeMsgText = 
                    chatPersona === 'expert'
                      ? "مرحباً بك! بصفتي خبيراً لغوياً، يسعدني مساعدتك في صياغة الجمل وتوضيح النحو والترجمة الدقيقة. تفضل بطرح سؤالك.\n\nWelcome! As your linguistics advisor, I am here to help you refine structure, understand grammar, and build elegant translations. Ask away!"
                      : chatPersona === 'advisor'
                      ? "أهلاً بك! أنا مستشارك المهني لتلميع المراسلات الرسمية والخطابات وتجهيز العروض المهنية. ما هو موضوع تواصلك اليوم؟\n\nWelcome! I am your professional communication advisor. Let's craft outstanding executive emails, business proposals, or interview scripts."
                      : chatPersona === 'cultural'
                      ? "مرحباً! بصفتي مستشاراً ثقافياً واجتماعياً، سأرشدك لقواعد الإتيكيت والتحايا المهذبة وأسرار اللباقة المهنية عبر الثقافات.\n\nHello! I am your cultural context and etiquette advisor. Let's master formal business custom protocols, social nuances, and polite formulations."
                      : "رائع! دعنا نتدرب سوياً على المحادثة الحرة والمصطلحات المهنية. اكتب لي جملاً أو عبارات وسأصححها لك وأعطيك نصائح لتلميعها.\n\nGreat! I'm your interactive speaking partner. Share any statement with me, and I will gently analyze, correct, and upgrade your vocabulary.";
                  
                  setChatMessages([
                    {
                      id: 'welcome',
                      role: 'assistant',
                      text: welcomeMsgText,
                      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                      persona: chatPersona
                    }
                  ]);
                  showChatToast("New conversation started • تم بدء محادثة جديدة");
                }}
                className="w-full bg-[#818cf8] hover:bg-indigo-400 text-zinc-950 font-sans font-bold py-3.5 px-4 rounded-xl text-xs transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98 shadow-[0_4px_15px_rgba(129,140,248,0.2)] hover:scale-[1.01]"
              >
                <Plus className="w-4 h-4 text-zinc-950" />
                <span className="text-zinc-950 font-extrabold">New Chat • محادثة جديدة</span>
              </button>

              {/* Persona Selection Card */}
              <div className="bg-[#0f0f12] border border-[#222222] rounded-2xl p-5 flex flex-col gap-4 shadow-[0_4px_30px_rgba(0,0,0,0.5)]">
                <div className="flex items-center gap-2 border-b border-[#222222] pb-3">
                  <Bot className="w-5 h-5 text-[#818cf8]" />
                  <div>
                    <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-400">Assistant Personas</h3>
                    <p className="text-[10px] text-zinc-500 font-sans mt-0.5">اختر الشخصية المناسبة لطبيعة استفسارك</p>
                  </div>
                </div>

                <div className="flex flex-col gap-2.5 font-sans">
                  {/* Persona 1: Expert */}
                  <button
                    onClick={() => {
                      setChatPersona('expert');
                      setChatMessages([
                        {
                          id: 'welcome',
                          role: 'assistant',
                          text: "مرحباً بك! بصفتي خبيراً لغوياً، يسعدني مساعدتك في صياغة الجمل وتوضيح النحو والترجمة الدقيقة. تفضل بطرح سؤالك.\n\nWelcome! As your linguistics advisor, I am here to help you refine structure, understand grammar, and build elegant translations. Ask away!",
                          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                          persona: 'expert'
                        }
                      ]);
                      showChatToast("Linguistics Expert active • تم تنشيط الخبير اللغوي");
                    }}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex gap-3.5 items-start ${
                      chatPersona === 'expert'
                        ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300 shadow-[0_4px_20px_rgba(16,185,129,0.05)]'
                        : 'bg-zinc-900/30 border-zinc-850 hover:border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    <div className={`p-2 rounded-lg shrink-0 ${chatPersona === 'expert' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-zinc-800 text-zinc-400'}`}>
                      <BookOpen className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold">Linguistics Expert • خبير لغوي</span>
                        {chatPersona === 'expert' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
                      </div>
                      <p className="text-[10px] text-zinc-500 mt-0.5 leading-relaxed">Grammar, idioms, comparisons & translation nuances.</p>
                    </div>
                  </button>

                  {/* Persona 2: Advisor */}
                  <button
                    onClick={() => {
                      setChatPersona('advisor');
                      setChatMessages([
                        {
                          id: 'welcome',
                          role: 'assistant',
                          text: "أهلاً بك! أنا مستشارك المهني لتلميع المراسلات الرسمية والخطابات وتجهيز العروض المهنية. ما هو موضوع تواصلك اليوم؟\n\nWelcome! I am your professional communication advisor. Let's craft outstanding executive emails, business proposals, or interview scripts.",
                          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                          persona: 'advisor'
                        }
                      ]);
                      showChatToast("Business Advisor active • تم تنشيط المستشار المهني");
                    }}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex gap-3.5 items-start ${
                      chatPersona === 'advisor'
                        ? 'bg-blue-950/20 border-blue-500/40 text-blue-300 shadow-[0_4px_20px_rgba(59,130,246,0.05)]'
                        : 'bg-zinc-900/30 border-zinc-850 hover:border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    <div className={`p-2 rounded-lg shrink-0 ${chatPersona === 'advisor' ? 'bg-blue-500/20 text-blue-400' : 'bg-zinc-800 text-zinc-400'}`}>
                      <Briefcase className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold">Business Advisor • صياغة مهنية</span>
                        {chatPersona === 'advisor' && <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />}
                      </div>
                      <p className="text-[10px] text-zinc-500 mt-0.5 leading-relaxed">Executive phrasing, corporate emails, proposals & interview practice.</p>
                    </div>
                  </button>

                  {/* Persona 3: Cultural */}
                  <button
                    onClick={() => {
                      setChatPersona('cultural');
                      setChatMessages([
                        {
                          id: 'welcome',
                          role: 'assistant',
                          text: "مرحباً! بصفتي مستشاراً ثقافياً واجتماعياً، سأرشدك لقواعد الإتيكيت والتحايا المهذبة وأسرار اللباقة المهنية عبر الثقافات.\n\nHello! I am your cultural context and etiquette advisor. Let's master formal business custom protocols, social nuances, and polite formulations.",
                          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                          persona: 'cultural'
                        }
                      ]);
                      showChatToast("Cultural Advisor active • تم تنشيط المستشار الثقافي");
                    }}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex gap-3.5 items-start ${
                      chatPersona === 'cultural'
                        ? 'bg-amber-950/20 border-amber-500/40 text-amber-300 shadow-[0_4px_20px_rgba(245,158,11,0.05)]'
                        : 'bg-zinc-900/30 border-zinc-850 hover:border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    <div className={`p-2 rounded-lg shrink-0 ${chatPersona === 'cultural' ? 'bg-amber-500/20 text-amber-400' : 'bg-zinc-800 text-zinc-400'}`}>
                      <Globe className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold">Cultural Coach • مستشار ثقافي</span>
                        {chatPersona === 'cultural' && <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />}
                      </div>
                      <p className="text-[10px] text-zinc-500 mt-0.5 leading-relaxed">International social protocols, polite greetings & honorifics.</p>
                    </div>
                  </button>

                  {/* Persona 4: Trainer */}
                  <button
                    onClick={() => {
                      setChatPersona('trainer');
                      setChatMessages([
                        {
                          id: 'welcome',
                          role: 'assistant',
                          text: "رائع! دعنا نتدرب سوياً على المحادثة الحرة والمصطلحات المهنية. اكتب لي جملاً أو عبارات وسأصححها لك وأعطيك نصائح لتلميعها.\n\nGreat! I'm your interactive speaking partner. Share any statement with me, and I will gently analyze, correct, and upgrade your vocabulary.",
                          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                          persona: 'trainer'
                        }
                      ]);
                      showChatToast("Speaking Partner active • تم تنشيط شريك المحادثة");
                    }}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex gap-3.5 items-start ${
                      chatPersona === 'trainer'
                        ? 'bg-indigo-950/20 border-[#818cf8]/40 text-indigo-300 shadow-[0_4px_20px_rgba(129,140,248,0.05)]'
                        : 'bg-zinc-900/30 border-zinc-850 hover:border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    <div className={`p-2 rounded-lg shrink-0 ${chatPersona === 'trainer' ? 'bg-indigo-500/20 text-indigo-400' : 'bg-zinc-800 text-zinc-400'}`}>
                      <MessagesSquare className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold">Practice Partner • مدرب محادثة</span>
                        {chatPersona === 'trainer' && <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />}
                      </div>
                      <p className="text-[10px] text-zinc-500 mt-0.5 leading-relaxed">Engaging conversations, grammar checks & immediate corrections.</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Speech Playback Settings inside Sidebar */}
              <div className="bg-[#0f0f12] border border-[#222222] rounded-2xl p-5 flex flex-col gap-4 shadow-[0_4px_30px_rgba(0,0,0,0.5)]">
                <div className="flex items-center gap-2 border-b border-[#222222] pb-3">
                  <Gauge className="w-4 h-4 text-[#818cf8]" />
                  <div>
                    <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-400">Speech Engine</h3>
                    <p className="text-[10px] text-zinc-500 font-sans mt-0.5">التحكم في سرعة نطق المساعد</p>
                  </div>
                </div>

                <div className="flex flex-col gap-3.5">
                  <div className="flex justify-between items-center text-xs text-zinc-400 font-mono">
                    <span>Playback Speed • السرعة</span>
                    <span className="text-[#818cf8] font-bold bg-[#818cf8]/10 px-2.5 py-0.5 rounded-full border border-[#818cf8]/25">{playbackSpeed}x</span>
                  </div>

                  <div className="flex gap-2.5">
                    {[0.5, 1.0, 1.5].map((speed) => (
                      <button
                        type="button"
                        key={speed}
                        onClick={() => setPlaybackSpeed(speed)}
                        className={`flex-1 py-2 text-xs font-mono font-bold rounded-lg border transition-all cursor-pointer ${
                          playbackSpeed === speed
                            ? 'bg-[#818cf8] text-zinc-950 border-[#818cf8]'
                            : 'bg-zinc-900 hover:bg-zinc-850 text-zinc-400 border-zinc-800'
                        }`}
                      >
                        {speed}x
                      </button>
                    ))}
                  </div>

                  <input
                    type="range"
                    min="0.5"
                    max="1.5"
                    step="0.1"
                    value={playbackSpeed}
                    onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                    className="w-full accent-[#818cf8] bg-zinc-900 rounded-lg appearance-none h-1 cursor-pointer mt-1"
                  />

                  {currentlySpeakingMessageId && (
                    <button
                      type="button"
                      onClick={stopSpeakingChatMessage}
                      className="bg-red-500/10 hover:bg-red-500/15 border border-red-500/20 text-red-400 py-2.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center justify-center gap-2 cursor-pointer mt-1"
                    >
                      <VolumeX className="w-4 h-4" />
                      Stop Speech • إيقاف الصوت
                    </button>
                  )}
                </div>
              </div>

              {/* Clear Chat Panel */}
              <button
                type="button"
                onClick={clearChatHistory}
                className="bg-zinc-950/40 hover:bg-zinc-900 border border-zinc-850 hover:border-zinc-800 p-4 rounded-2xl flex items-center justify-between cursor-pointer transition-colors w-full"
              >
                <div className="flex items-center gap-3">
                  <div className="bg-red-950/20 p-2 rounded-xl text-red-400 border border-red-900/10">
                    <Trash2 className="w-4 h-4" />
                  </div>
                  <div className="text-left font-sans">
                    <h4 className="text-xs font-bold text-zinc-300">Clear Conversations</h4>
                    <p className="text-[9px] text-zinc-500 font-mono mt-0.5">مسح سجل المحادثة بالكامل</p>
                  </div>
                </div>
              </button>

            </div>

            {/* Right Column: Chat Feed Room */}
            <div className="lg:col-span-8 flex flex-col bg-[#121212] border border-[#222222] rounded-2xl p-5 sm:p-6 shadow-[0_4px_30px_rgba(0,0,0,0.5)] relative select-text">
              
              {/* Chat Toast Notification */}
              <AnimatePresence>
                {chatToast && (
                  <motion.div
                    initial={{ opacity: 0, y: -20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -20, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute top-16 left-1/2 -translate-x-1/2 z-30 bg-indigo-950/90 border border-indigo-500/30 px-4 py-2 rounded-xl shadow-[0_4px_25px_rgba(129,140,248,0.25)] backdrop-blur-md flex items-center gap-2 text-indigo-200 text-xs font-medium font-sans"
                  >
                    <Check className="w-4 h-4 text-indigo-400" />
                    <span>{chatToast}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Chat Feed Header */}
              <div className="flex items-center justify-between pb-4 border-b border-zinc-850 mb-5 select-none">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="w-10 h-10 rounded-full bg-[#818cf8]/15 border border-[#818cf8]/30 flex items-center justify-center text-[#818cf8]">
                      <Bot className="w-5 h-5 animate-pulse" />
                    </div>
                    <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-[#121212]" />
                  </div>
                  <div className="text-left font-sans">
                    <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                      Linguistics Bot
                      <span className="text-[10px] text-emerald-400 font-mono normal-case bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/15">Active</span>
                    </h4>
                    <p className="text-[10px] text-zinc-500 font-mono">
                      Persona: <span className="text-[#818cf8] font-bold uppercase">{chatPersona}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-zinc-500 font-mono tracking-widest uppercase flex items-center gap-1.5 bg-zinc-950/60 px-3 py-1.5 rounded-full border border-zinc-850/50">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                    Fast • سريع
                  </span>
                </div>
              </div>

              {/* Messages Container */}
              <div className="flex-1 min-h-[380px] max-h-[580px] overflow-y-auto flex flex-col gap-5 pr-1.5 mb-5 select-text">
                {chatMessages.length <= 1 ? (
                  /* Immersive ChatGPT Welcome Hero Screen */
                  <div className="flex-grow flex flex-col items-center justify-center py-8 text-center px-4 max-w-xl mx-auto my-auto font-sans animate-fade-in select-none">
                    <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/25 flex items-center justify-center text-indigo-400 mb-5 shadow-[0_0_25px_rgba(129,140,248,0.15)]">
                      <Bot className="w-7 h-7" />
                    </div>
                    
                    <h3 className="text-lg md:text-xl font-extrabold text-white tracking-tight leading-tight">
                      How can I assist you today?
                    </h3>
                    <p className="text-zinc-400 text-xs mt-1.5 max-w-sm">
                      كيف يمكنني مساعدتك اليوم؟ اختر أحد المواضيع المقترحة بالأسفل لبدء حوار تفاعلي ذكي.
                    </p>
                    
                    {/* ChatGPT 2x2 grid of Modern Prompt Cards */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 w-full mt-8 text-left">
                      {PERSONA_SUGGESTIONS[chatPersona].map((suggestion, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleSendChatMessage(undefined, suggestion.text)}
                          className="bg-zinc-900/40 hover:bg-[#818cf8]/10 border border-zinc-850/60 hover:border-[#818cf8]/30 p-4 rounded-xl text-left transition-all cursor-pointer group hover:scale-[1.01] active:scale-98 flex flex-col justify-between"
                        >
                          <div>
                            <span className="text-[9px] font-mono font-bold text-[#818cf8] uppercase tracking-wider block">Prompt Idea • مقترح</span>
                            <h4 className="text-xs text-zinc-200 group-hover:text-white font-sans font-bold mt-1.5 leading-snug">
                              {suggestion.label}
                            </h4>
                          </div>
                          <p className="text-[10px] text-zinc-500 group-hover:text-zinc-400 mt-2 font-sans truncate w-full">
                            "{suggestion.text}"
                          </p>
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  /* Standard ChatGPT Message Feed List */
                  <AnimatePresence initial={false}>
                    {chatMessages.map((msg) => {
                      const isUser = msg.role === 'user';
                      const isMsgSpeaking = currentlySpeakingMessageId === msg.id;
                      const hasArabicText = /[\u0600-\u06FF]/.test(msg.text);

                      return (
                        <motion.div
                          key={msg.id}
                          initial={{ opacity: 0, y: 15 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.2, ease: "easeOut" }}
                          className={`flex flex-col gap-1.5 max-w-[85%] ${isUser ? 'ml-auto items-end' : 'mr-auto items-start'}`}
                        >
                          {/* Meta info */}
                          <div className="flex items-center gap-2 px-1 text-[9px] text-zinc-500 font-mono">
                            {isUser ? (
                              <>
                                <span>{msg.timestamp}</span>
                                <span className="text-zinc-700">•</span>
                                <span className="text-indigo-400 font-bold uppercase">You</span>
                              </>
                            ) : (
                              <>
                                <span className="text-[#818cf8] font-bold uppercase">Assistant ({msg.persona})</span>
                                <span className="text-zinc-700">•</span>
                                <span>{msg.timestamp}</span>
                              </>
                            )}
                          </div>

                          {/* Speech Bubble */}
                          <div
                            className={`p-4 rounded-2xl relative border ${
                              isUser
                                ? 'bg-indigo-950/20 border-[#818cf8]/25 text-zinc-100 rounded-tr-none'
                                : 'bg-zinc-900/40 border-zinc-850 text-zinc-100 rounded-tl-none'
                            }`}
                            style={{ direction: hasArabicText ? 'rtl' : 'ltr', textAlign: hasArabicText ? 'right' : 'left' }}
                          >
                            <div className="whitespace-pre-wrap select-text selection:bg-[#818cf8]/30 selection:text-white leading-relaxed">
                              {renderFormattedText(msg.text)}
                            </div>

                            {/* Sound wave overlay when speaking */}
                            {isMsgSpeaking && (
                              <div className="flex items-center gap-1.5 mt-3 pt-2.5 border-t border-zinc-800 justify-start">
                                <span className="text-[10px] text-[#818cf8] font-mono uppercase tracking-widest font-bold">Speaking...</span>
                                <div className="flex items-end gap-0.5 h-3">
                                  {[1, 2, 3, 4, 5].map((bar) => (
                                    <span
                                      key={bar}
                                      className="w-0.5 bg-[#818cf8] rounded-full animate-bounce"
                                      style={{
                                        height: `${20 + Math.random() * 80}%`,
                                        animationDuration: `${0.2 + Math.random() * 0.3}s`
                                      }}
                                    />
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Interactive Message Toolbar */}
                          {!isUser && (
                            <div className="flex items-center gap-1.5 px-1 mt-0.5">
                              <button
                                type="button"
                                onClick={() => speakChatMessage(msg)}
                                className={`p-1.5 rounded-lg border text-[10px] font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                                  isMsgSpeaking
                                    ? 'bg-red-500/10 border-red-500/20 text-red-400 hover:bg-red-500/15'
                                    : 'bg-zinc-900 hover:bg-zinc-850 border-zinc-800 text-zinc-400 hover:text-white'
                                }`}
                              >
                                {isMsgSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                                <span>{isMsgSpeaking ? 'Stop • إيقاف' : 'Listen • استماع'}</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  navigator.clipboard.writeText(msg.text);
                                  showChatToast('Text copied! • تم نسخ النص بنجاح');
                                }}
                                className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-zinc-400 hover:text-white text-[10px] font-mono flex items-center gap-1.5 transition-all cursor-pointer"
                              >
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copy • نسخ</span>
                              </button>
                            </div>
                          )}
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                )}

                {/* Typing / Loading indicator */}
                {isChatLoading && (
                  <div className="flex flex-col gap-1.5 max-w-[85%] mr-auto items-start animate-pulse">
                    <div className="flex items-center gap-2 px-1 text-[9px] text-zinc-500 font-mono">
                      <span className="text-[#818cf8] font-bold uppercase">Assistant ({chatPersona})</span>
                      <span className="text-zinc-700">•</span>
                      <span>Writing...</span>
                    </div>
                    
                    <div className="bg-zinc-900/30 border border-zinc-850 p-4 rounded-2xl rounded-tl-none flex items-center gap-3">
                      <Loader2 className="w-4 h-4 text-[#818cf8] animate-spin" />
                      <span className="text-xs text-zinc-400 font-mono">Neural Engine is crafting response... • جاري الصياغة</span>
                    </div>
                  </div>
                )}
                
                {/* Scroll Anchor */}
                <div ref={chatEndRef} />
              </div>

              {/* Bottom Quick Suggestion Pill Drawer (Visible only after some chat has started) */}
              {chatMessages.length > 1 && (
                <div className="border-t border-zinc-850/60 pt-3 mb-2 animate-fade-in">
                  <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold text-zinc-500 uppercase tracking-wider mb-2">
                    <Sparkles className="w-3 h-3 text-[#818cf8]" />
                    <span>Suggestions • مقترحات سريعة</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {PERSONA_SUGGESTIONS[chatPersona].map((suggestion, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => handleSendChatMessage(undefined, suggestion.text)}
                        disabled={isChatLoading || isRecording}
                        className="bg-zinc-900/50 hover:bg-[#818cf8]/10 hover:text-white border border-zinc-850 hover:border-[#818cf8]/30 px-3 py-1.5 rounded-xl text-[10px] font-sans text-zinc-400 font-medium transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 disabled:opacity-40"
                      >
                        <span>{suggestion.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* ChatGPT styled Integrated Input Bar */}
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendChatMessage(e);
                }} 
                className="flex gap-2.5 items-end mt-auto border-t border-zinc-850 pt-3 relative"
              >
                {/* Microphone Record Button */}
                <button
                  type="button"
                  onClick={() => {
                    if (subStatus === 'expired') {
                      setErrorMessage("انتهت الفترة التجريبية المجانية! يرجى الترقية إلى الباقة المميزة لمتابعة استخدام محرك الترجمة والدردشة.");
                      setIsPaymentModalOpen(true);
                      return;
                    }

                    setIsRecording(true);
                    setErrorMessage(null);
                    
                    setTimeout(() => {
                      setIsRecording(false);
                      
                      let transcribedSpeech = '';
                      if (chatPersona === 'expert') {
                        transcribedSpeech = "ما هو الفرق بين صيغة الفعل المضارع البسيط والمستمر؟";
                      } else if (chatPersona === 'advisor') {
                        transcribedSpeech = "أحتاج لمسودة سريعة لبريد رسمي لإلغاء الموعد.";
                      } else if (chatPersona === 'cultural') {
                        transcribedSpeech = "كيف يقدم المدراء بطاقات العمل في اليابان؟";
                      } else {
                        transcribedSpeech = "أريد التدرب على تحية العملاء باللغة الإنجليزية في الفندق.";
                      }
                      
                      setChatInput(transcribedSpeech);
                    }, 2000);
                  }}
                  className={`p-3.5 rounded-xl border transition-all shrink-0 cursor-pointer ${
                    isRecording
                      ? 'bg-rose-500/10 border-rose-500/30 text-rose-400 animate-pulse'
                      : 'bg-zinc-900 hover:bg-zinc-850 border-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                  title="Speech-to-Text Voice Recording"
                >
                  <Mic className={`w-4 h-4 ${isRecording ? 'scale-110' : ''}`} />
                </button>

                {/* Auto-expanding Textarea input box mimicking ChatGPT's multi-line capability */}
                <div className="flex-1 relative flex items-center">
                  <textarea
                    rows={1}
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendChatMessage(e);
                      }
                    }}
                    placeholder={
                      isRecording
                        ? "Recording audio... • جاري تسجيل الصوت..."
                        : "Type message... (Press Enter to Send, Shift+Enter for new line) • اكتب استفسارك هنا..."
                    }
                    disabled={isRecording || isChatLoading}
                    className="w-full bg-zinc-950/60 border border-zinc-850 hover:border-zinc-800 focus:border-[#818cf8] rounded-xl pl-4 pr-12 py-3.5 text-sm text-zinc-100 placeholder-zinc-500 outline-none transition-all focus:shadow-[0_0_15px_rgba(129,140,248,0.1)] resize-none max-h-32 min-h-[48px] overflow-y-auto leading-relaxed"
                  />
                  
                  {/* Integrated Send Button inside the text area for a cleaner design */}
                  <button
                    type="submit"
                    disabled={!chatInput.trim() || isChatLoading || isRecording}
                    className="absolute right-2.5 bottom-2 bg-[#818cf8] hover:bg-[#818cf8]/90 disabled:bg-zinc-850 text-zinc-950 disabled:text-zinc-600 p-2.5 rounded-lg transition-all cursor-pointer flex items-center justify-center shadow-[0_2px_8px_rgba(129,140,248,0.15)] disabled:shadow-none"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>

            </div>

          </div>
        )}

        {/* Global Bottom Interactive Floating Control Tray */}
        <footer className="mt-auto pt-8 pb-4 border-t border-[#222222] flex flex-col sm:flex-row justify-between items-center gap-6">
          
          <div className="text-xs text-zinc-500 flex items-center gap-1.5 order-2 sm:order-1">
            <span>Lingua AI v1.0</span>
            <span className="text-zinc-700">•</span>
            <span>Powered by Gemini 3.5 & 3.1 Neural Models</span>
          </div>

          {/* Core Interactive Microphone Recording & Wave Simulation Button */}
          <div className="flex justify-center items-center gap-8 order-1 sm:order-2">
            
            <button 
              onClick={() => {
                setSourceText('');
                setTranslatedText('');
                setToneDetected('Awaiting Input');
                setToneExplanation('Cleared all translation cells.');
                setSuggestions(['Formal corporate report', 'Casual conversational', 'Similar Phrases']);
              }}
              className="w-12 h-12 rounded-full border border-[#222222] hover:border-zinc-700 text-zinc-400 hover:text-white flex justify-center items-center transition-all bg-zinc-900/40 cursor-pointer text-sm"
              title="Clear all text fields"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Neural Mic Launcher */}
            <div className="relative">
              {isRecording && (
                <span className="absolute -inset-2 rounded-full bg-red-500/10 border border-red-500/20 animate-pulse scale-125" />
              )}
              <button 
                onClick={startRecording}
                className={`w-20 h-20 rounded-full flex justify-center items-center transition-all cursor-pointer ${
                  isRecording 
                    ? 'bg-red-600 shadow-[0_0_25px_rgba(239,68,68,0.55)] border border-red-500' 
                    : 'bg-[#818cf8] shadow-[0_8px_30px_rgba(129,140,248,0.4)] border border-[#6366f1] hover:scale-105'
                }`}
                title={isRecording ? "Stop voice recording and translate with Gemini" : "Record voice translation input"}
              >
                {isRecording ? (
                  <Square className="w-6 h-6 text-white" />
                ) : (
                  <Mic className="w-7 h-7 text-white" />
                )}
              </button>
            </div>

            <button 
              onClick={() => setShowHistoryOnly(prev => !prev)}
              className={`w-12 h-12 rounded-full border flex justify-center items-center transition-all cursor-pointer ${
                showHistoryOnly 
                  ? 'bg-indigo-600 text-white border-indigo-500' 
                  : 'border-[#222222] hover:border-zinc-700 text-zinc-400 hover:text-white bg-zinc-900/40'
              }`}
              title="Toggle Notebook history log"
            >
              <History className="w-4 h-4" />
            </button>

          </div>

          <div className="text-xs text-zinc-500 flex items-center gap-1.5 order-3">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
            <span>Secure SSL Encrypted Channel</span>
          </div>

        </footer>

        {/* Premium Payment & Subscription Modal */}
        <AnimatePresence>
          {isPaymentModalOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto"
            >
              <motion.div
                initial={{ scale: 0.95, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 20 }}
                className="bg-[#0f0f12] border border-[#222222] rounded-3xl w-full max-w-lg p-6 sm:p-8 flex flex-col gap-5 relative shadow-[0_10px_50px_rgba(0,0,0,0.85)] max-h-[95vh] overflow-y-auto"
              >
                {/* Close Button */}
                <button
                  onClick={closePaymentModal}
                  disabled={isProcessingPayment}
                  className="absolute top-4 right-4 text-zinc-400 hover:text-white p-2 rounded-full bg-zinc-900/60 hover:bg-zinc-800 transition-colors cursor-pointer"
                  title="Close modal"
                >
                  <X className="w-4 h-4" />
                </button>

                {/* Modal Header */}
                {!paymentSuccess ? (
                  <div className="text-center sm:text-left">
                    <div className="mx-auto sm:mx-0 bg-amber-500/10 border border-amber-500/20 text-amber-400 p-2.5 rounded-xl inline-block mb-3">
                      <Award className="w-6 h-6 animate-pulse" />
                    </div>
                    <h2 className="font-serif italic text-2xl text-white">
                      Upgrade to Premium • ترقية الاشتراك
                    </h2>
                    <p className="text-zinc-400 text-xs mt-1">
                      Start your 1-week free trial, then continue for just <strong className="text-[#818cf8]">$25 for 2 months</strong>.
                    </p>
                    <p className="text-zinc-500 text-[11px] font-sans dir-rtl text-right mt-1">
                      ابدأ أسبوعك المجاني أولاً، ثم استمر بقيمة <strong className="text-[#818cf8]">٢٥ دولار فقط لمدة شهرين</strong>.
                    </p>
                  </div>
                ) : null}

                {/* Main Modal Body */}
                {isProcessingPayment ? (
                  /* Loading / Processing State */
                  <div className="py-12 flex flex-col items-center justify-center text-center gap-4">
                    <Loader2 className="w-12 h-12 text-[#818cf8] animate-spin" />
                    <div className="space-y-1">
                      <p className="text-sm font-mono text-zinc-300">
                        Processing secure payment transaction...
                      </p>
                      <p className="text-xs text-zinc-500">
                        Securing connection with bank network via PCI-DSS 3D-Secure...
                      </p>
                      <p className="text-xs font-serif italic text-[#818cf8] mt-2 dir-rtl text-right">
                        جاري معالجة الدفع الآمن المتوافق مع معايير الأمان العالمية للبنوك...
                      </p>
                    </div>
                  </div>
                ) : paymentSuccess ? (
                  /* Success State */
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="py-8 flex flex-col items-center justify-center text-center gap-5"
                  >
                    <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-4 rounded-full inline-block animate-bounce">
                      <CheckCircle2 className="w-12 h-12" />
                    </div>
                    
                    <div>
                      <h3 className="font-serif italic text-2xl text-white">
                        Subscription Activated! • تم التفعيل بنجاح!
                      </h3>
                      <p className="text-zinc-400 text-sm mt-2 leading-relaxed max-w-sm mx-auto">
                        Your premium account is now active with unlimited translation capability for <strong className="text-emerald-400">2 months</strong>.
                      </p>
                      <p className="text-zinc-500 text-xs mt-1 leading-relaxed max-w-sm mx-auto dir-rtl text-right">
                        عضويتك المميزة نشطة الآن وتمنحك استخداماً غير محدود لجميع مزايا الترجمة الذكية <strong className="text-emerald-400">لمدة شهرين كاملين</strong>.
                      </p>
                    </div>

                    <button
                      onClick={closePaymentModal}
                      className="mt-4 w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-semibold py-3 rounded-xl transition-all duration-200 shadow-[0_4px_15px_rgba(16,185,129,0.3)] cursor-pointer"
                    >
                      Start Translating • ابدأ استخدام الترجمة المميزة
                    </button>
                  </motion.div>
                ) : (
                  /* Payment Form State */
                  <div className="flex flex-col gap-5">
                    
                    {/* Offer Highlight Box */}
                    <div className="bg-zinc-950/80 rounded-2xl p-4 border border-zinc-900 flex flex-col gap-2">
                      <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                        <span className="text-xs text-zinc-400">Plan Option • نوع الباقة:</span>
                        <span className="text-xs font-mono font-bold text-amber-400 uppercase">Dual-Month Saver</span>
                      </div>
                      <div className="flex justify-between items-start pt-1">
                        <div>
                          <p className="text-sm font-serif font-bold text-white">1-Week Free Trial, then $25</p>
                          <p className="text-[11px] text-zinc-500">Includes offline pack support & full AI glossary</p>
                        </div>
                        <div className="text-right">
                          <p className="text-base font-bold text-[#818cf8]">$25.00 <span className="text-zinc-500 text-[10px] font-normal">/ 2mo</span></p>
                          <p className="text-[10px] text-zinc-500">أول أسبوع مجاناً، ثم ٢٥$ لشهرين</p>
                        </div>
                      </div>
                    </div>

                    {/* Payment Method Selector Tabs */}
                    <div className="flex flex-wrap gap-2 justify-between border-b border-zinc-900 pb-3">
                      <button
                        type="button"
                        onClick={() => setSelectedPayment('card')}
                        className={`flex-1 py-2 px-3 rounded-xl border text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                          selectedPayment === 'card'
                            ? 'bg-zinc-900 text-white border-zinc-700'
                            : 'bg-transparent text-zinc-500 border-transparent hover:text-zinc-300'
                        }`}
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        Credit Card
                      </button>

                      <button
                        type="button"
                        onClick={() => setSelectedPayment('mada')}
                        className={`flex-1 py-2 px-3 rounded-xl border text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                          selectedPayment === 'mada'
                            ? 'bg-emerald-950/25 text-emerald-400 border-emerald-900/40 shadow-inner'
                            : 'bg-transparent text-zinc-500 border-transparent hover:text-zinc-300'
                        }`}
                      >
                        <span className="text-[10px] uppercase font-sans font-extrabold tracking-tight text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">mada</span>
                        مدى
                      </button>

                      <button
                        type="button"
                        onClick={() => setSelectedPayment('apple')}
                        className={`flex-1 py-2 px-3 rounded-xl border text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                          selectedPayment === 'apple'
                            ? 'bg-zinc-900 text-white border-zinc-700'
                            : 'bg-transparent text-zinc-500 border-transparent hover:text-zinc-300'
                        }`}
                      >
                        <span className="font-bold text-zinc-200 bg-zinc-800 px-1.5 py-0.5 rounded text-[10px]"> Pay</span>
                        آبل باي
                      </button>

                      <button
                        type="button"
                        onClick={() => setSelectedPayment('paypal')}
                        className={`flex-1 py-2 px-3 rounded-xl border text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                          selectedPayment === 'paypal'
                            ? 'bg-blue-950/20 text-blue-400 border-blue-900/30'
                            : 'bg-transparent text-zinc-500 border-transparent hover:text-zinc-300'
                        }`}
                      >
                        <span className="text-blue-500 font-extrabold">PayPal</span>
                      </button>
                    </div>

                    {/* Interactive Forms based on Selected Tab */}
                    {selectedPayment === 'card' || selectedPayment === 'mada' ? (
                      /* Credit Card & Mada Form */
                      <form onSubmit={handleProcessPayment} className="flex flex-col gap-4">
                        
                        {/* Dynamic Card Display Mock */}
                        <div className={`p-5 rounded-2xl border flex flex-col justify-between h-40 relative overflow-hidden transition-all duration-300 ${
                          selectedPayment === 'mada'
                            ? 'bg-gradient-to-br from-emerald-950 to-zinc-950 border-emerald-500/30 text-emerald-100 shadow-[0_10px_30px_rgba(16,185,129,0.08)]'
                            : 'bg-gradient-to-br from-indigo-950 via-zinc-950 to-zinc-900 border-zinc-800 text-zinc-100'
                        }`}>
                          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />
                          
                          <div className="flex justify-between items-start z-10">
                            <div>
                              <p className="text-[10px] uppercase font-mono tracking-widest text-zinc-500">Lingua AI Secure Card</p>
                              <p className="text-xs font-sans text-zinc-400">{selectedPayment === 'mada' ? 'Mada Card / بطاقة مدى للخصم' : 'Standard Credit Card'}</p>
                            </div>
                            {selectedPayment === 'mada' ? (
                              <span className="text-xs font-sans font-extrabold tracking-tight text-white bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-400/30">mada مدى</span>
                            ) : (
                              <CreditCard className="w-6 h-6 text-zinc-400" />
                            )}
                          </div>

                          <div className="z-10 font-mono text-lg tracking-widest my-2">
                            {cardNumber || '•••• •••• •••• ••••'}
                          </div>

                          <div className="flex justify-between items-center z-10 text-xs font-mono">
                            <div>
                              <p className="text-[8px] text-zinc-500 uppercase tracking-widest">Card Holder • الاسم</p>
                              <p className="truncate max-w-[150px]">{cardHolder || 'CARD HOLDER NAME'}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-[8px] text-zinc-500 uppercase tracking-widest">Expiry • ينتهي</p>
                              <p>{cardExpiry || 'MM/YY'}</p>
                            </div>
                          </div>
                        </div>

                        {/* Input Fields */}
                        <div className="grid grid-cols-2 gap-3">
                          <div className="col-span-2">
                            <label className="block text-[10px] uppercase tracking-wider text-zinc-500 font-mono mb-1">
                              Cardholder Name • اسم صاحب البطاقة
                            </label>
                            <input
                              type="text"
                              required
                              value={cardHolder}
                              onChange={(e) => setCardHolder(e.target.value)}
                              placeholder="e.g. Anwar Al-Mutairi"
                              className="w-full bg-zinc-950 border border-zinc-900 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-indigo-500/50"
                            />
                          </div>

                          <div className="col-span-2">
                            <label className="block text-[10px] uppercase tracking-wider text-zinc-500 font-mono mb-1">
                              Card Number • رقم البطاقة
                            </label>
                            <input
                              type="text"
                              required
                              maxLength={19}
                              value={cardNumber}
                              onChange={(e) => {
                                // Add space format
                                const val = e.target.value.replace(/\s?/g, '').replace(/(\d{4})/g, '$1 ').trim();
                                setCardNumber(val);
                              }}
                              placeholder="4000 1234 5678 9010"
                              className="w-full bg-zinc-950 border border-zinc-900 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-indigo-500/50"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] uppercase tracking-wider text-zinc-500 font-mono mb-1">
                              Expiry Date • تاريخ الانتهاء
                            </label>
                            <input
                              type="text"
                              required
                              maxLength={5}
                              value={cardExpiry}
                              onChange={(e) => {
                                // Expiry format MM/YY
                                let val = e.target.value.replace(/\//g, '');
                                if (val.length > 2) {
                                  val = val.substring(0, 2) + '/' + val.substring(2);
                                }
                                setCardExpiry(val);
                              }}
                              placeholder="MM/YY"
                              className="w-full bg-zinc-950 border border-zinc-900 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-indigo-500/50"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] uppercase tracking-wider text-zinc-500 font-mono mb-1">
                              Security CVV • الرمز السري
                            </label>
                            <input
                              type="password"
                              required
                              maxLength={3}
                              value={cardCvv}
                              onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                              placeholder="•••"
                              className="w-full bg-zinc-950 border border-zinc-900 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-indigo-500/50"
                            />
                          </div>
                        </div>

                        {/* Security Badge */}
                        <div className="flex items-center gap-1.5 text-zinc-600 justify-center py-1">
                          <Lock className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="text-[10px] font-mono text-zinc-500">Secure, end-to-end 256-bit SSL connection</span>
                        </div>

                        {/* Submit Button */}
                        <button
                          type="submit"
                          className="w-full bg-[#818cf8] text-zinc-950 hover:bg-indigo-300 font-semibold py-3 rounded-xl transition-all duration-200 shadow-[0_4px_15px_rgba(129,140,248,0.3)] hover:scale-101 cursor-pointer flex justify-center items-center gap-2"
                        >
                          <Lock className="w-4 h-4 text-zinc-950" />
                          Activate 1-Week Free Trial, Then $25/2mo
                        </button>
                        <p className="text-[10px] text-zinc-500 text-center -mt-1 font-sans">
                          تفعيل أسبوعك المجاني الآن، ولن يتم سحب أي مبلغ إلا بعد انتهاء التجربة
                        </p>
                      </form>
                    ) : selectedPayment === 'apple' ? (
                      /* Apple Pay layout */
                      <div className="flex flex-col gap-4 py-3">
                        <div className="text-center py-4 bg-zinc-950/60 rounded-2xl border border-zinc-900 flex flex-col items-center gap-2">
                          <span className="text-4xl"> Pay</span>
                          <p className="text-xs text-zinc-400 font-sans px-6 leading-relaxed">
                            Double click side button on your Apple device to authorize translation services.
                          </p>
                          <p className="text-[11px] text-zinc-500 font-sans px-6 dir-rtl text-right">
                            اضغط مرتين على الزر الجانبي لتأكيد عملية الدفع من جهاز Apple الخاص بك.
                          </p>
                        </div>

                        <button
                          onClick={handleProcessPayment}
                          className="w-full bg-white text-black hover:bg-zinc-200 font-bold py-3 rounded-xl transition-all duration-200 shadow-[0_4px_15px_rgba(255,255,255,0.1)] cursor-pointer flex justify-center items-center gap-2"
                        >
                           Pay with Apple Pay
                        </button>
                      </div>
                    ) : (
                      /* PayPal layout */
                      <div className="flex flex-col gap-4 py-3">
                        <div className="text-center py-4 bg-zinc-950/60 rounded-2xl border border-zinc-900 flex flex-col items-center gap-2">
                          <span className="text-2xl font-bold italic text-blue-500">PayPal</span>
                          <p className="text-xs text-zinc-400 font-sans px-6 leading-relaxed">
                            You will be redirected to PayPal's secure server to authorize this billing subscription.
                          </p>
                          <p className="text-[11px] text-zinc-500 font-sans px-6 dir-rtl text-right">
                            سيتم توجيهك إلى خوادم PayPal الآمنة لتسجيل الدخول والموافقة على الترقية.
                          </p>
                        </div>

                        <button
                          onClick={handleProcessPayment}
                          className="w-full bg-[#ffc439] hover:bg-[#f4b31a] text-[#003087] font-bold py-3 rounded-xl transition-all duration-200 shadow-[0_4px_15px_rgba(255,196,57,0.25)] cursor-pointer flex justify-center items-center gap-2"
                        >
                          PayPal Checkout
                        </button>
                      </div>
                    )}

                    {/* Security Seals */}
                    <div className="flex items-center justify-between border-t border-zinc-900 pt-4 text-[10px] text-zinc-500 font-mono">
                      <div className="flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Verified Merchant</span>
                      </div>
                      <span>PCI-DSS Compliant</span>
                    </div>

                  </div>
                )}

              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
